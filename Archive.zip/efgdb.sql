-- Adminer 4.8.1 MySQL 8.0.28-0ubuntu0.20.04.3 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `arkaccountinfo`;
CREATE TABLE `arkaccountinfo` (
  `arkaccountinfo_id` varchar(21) NOT NULL,
  `customer_number` varchar(15) NOT NULL,
  `account_number` varchar(15) NOT NULL,
  `balance` varchar(15) NOT NULL,
  `bankacctype` varchar(50) NOT NULL,
  PRIMARY KEY (`arkaccountinfo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `arkaccountinfo` (`arkaccountinfo_id`, `customer_number`, `account_number`, `balance`, `bankacctype`) VALUES
('d41PMNeoDzKA9u97EdAQk',	'657596044',	'1004700001',	'375500',	'Numbered Private Account'),
('GGItksuc5NKdGyEIKHCZE',	'608284929',	'1000784900',	'385800',	'Numbered Private Account'),
('LMfUdij6Z1B7C0fKQXCRH',	'676421495',	'1008568330',	'455450',	'Numbered Private Account'),
('O3FNsKOWN8h5UIpmmiMLW',	'750048803',	'1007667850',	'358200',	'Numbered Private Account');

DROP TABLE IF EXISTS `arkaccountvalidation`;
CREATE TABLE `arkaccountvalidation` (
  `arkaccountvalidation_id` varchar(15) NOT NULL,
  `customer_number` varchar(21) NOT NULL,
  `identification_number` varchar(35) NOT NULL,
  `other_information` text NOT NULL,
  `datetime` int NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`arkaccountvalidation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `arkcardrequest`;
CREATE TABLE `arkcardrequest` (
  `arkcardrequest_id` varchar(15) NOT NULL,
  `customer_number` int NOT NULL,
  `cardtype` varchar(15) NOT NULL,
  `instruction` text NOT NULL,
  `datetime` int NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`arkcardrequest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `arkexttransfercode`;
CREATE TABLE `arkexttransfercode` (
  `arkexttransfercode_id` varchar(15) NOT NULL,
  `code` int NOT NULL,
  `codestatus` int NOT NULL,
  `code1` int NOT NULL,
  `code1status` int NOT NULL,
  `code2` int NOT NULL,
  `code2status` int NOT NULL,
  `code3` int NOT NULL,
  `code3status` int NOT NULL,
  `code4` int NOT NULL,
  `code4status` int NOT NULL,
  PRIMARY KEY (`arkexttransfercode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `arkexttransfercode` (`arkexttransfercode_id`, `code`, `codestatus`, `code1`, `code1status`, `code2`, `code2status`, `code3`, `code3status`, `code4`, `code4status`) VALUES
('i7GK6MZV2xGKkcZ',	25776,	1,	28877,	1,	16471,	0,	53730,	0,	49898,	0),
('Kv7QMU33tF0Xzpo',	14193,	0,	34011,	0,	40170,	0,	16694,	0,	33620,	0),
('T1TFKW78gmvKsL3',	13040,	0,	16265,	0,	39859,	0,	53705,	0,	28899,	0),
('w1bZG1O0PU3Bfa0',	17819,	0,	31619,	0,	34593,	0,	18859,	0,	37506,	0);

DROP TABLE IF EXISTS `arkhtmlmail`;
CREATE TABLE `arkhtmlmail` (
  `arkhtmlmail_id` varchar(15) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `recepient` varchar(75) NOT NULL,
  `mailcontent` text NOT NULL,
  `datetime` int NOT NULL,
  PRIMARY KEY (`arkhtmlmail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `arklog`;
CREATE TABLE `arklog` (
  `arklog_id` varchar(15) NOT NULL,
  `user_id` varchar(21) NOT NULL,
  `description` text NOT NULL,
  `datetime` int NOT NULL,
  PRIMARY KEY (`arklog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `arklog` (`arklog_id`, `user_id`, `description`, `datetime`) VALUES
('2HRBdnzSbmBy7xe',	'189115630',	'External Bank Transfer Initiated by User',	1644729424),
('9dRKQ2pTiIKBtjM',	'676421495',	'Password Changed by User',	1644826714),
('AuQevZ3GwAQfz4L',	'242333099',	'Account Credited (Deposit) by Administrator',	1644728071),
('CN79ONdUCmtdT4C',	'242333099',	'User Account Created by Administrator',	1644733163),
('DpoV6NkwRyKJh3o',	'676421495',	'External Bank Transfer Initiated by User',	1645206338),
('DsZ1iMV37R6NeGd',	'242333099',	'Account Credited (Deposit) by Administrator',	1645440409),
('El8xMzZlOSVCY9V',	'676421495',	'Verification Code 1 Entered by User',	1645442191),
('fzxrEtvIyyWB2c0',	'242333099',	'Account Credited (Deposit) by Administrator',	1644733928),
('G0g0xNzBz7ljDvm',	'242333099',	'Account Credited (Deposit) by Administrator',	1645112898),
('GCe8XjqZtrIsYgQ',	'242333099',	'User Account Created by Administrator',	1644817132),
('gCiwIPmRTd4UvUY',	'676421495',	'Verification Code 2 Entered by User',	1645703985),
('mrMgSs02lGEQyKB',	'242333099',	'Account Credited (Deposit) by Administrator',	1644728620),
('nogJpHjNqWLtJ83',	'242333099',	'Account Credited (Deposit) by Administrator',	1645440339),
('p5Y1wwXV4l2Zabx',	'242333099',	'User Account Created by Administrator',	1644727671),
('pN28nWYlMvyoumg',	'750048803',	'External Bank Transfer Initiated by User',	1645524344),
('po4mampzTuuzeqB',	'242333099',	'Account Credited (Deposit) by Administrator',	1644916469),
('RqqRYDiarH3hJpa',	'242333099',	'Password Changed by Administrator',	1645463846),
('SFNN3VIm3aT81r7',	'242333099',	'Account Credited (Deposit) by Administrator',	1645539705),
('tRake3EXDuxSku4',	'657596044',	'Password Changed by User',	1644835494),
('TUWWDqkxgjzaH01',	'242333099',	'Account Credited (Deposit) by Administrator',	1645058264),
('U1Fi7jwZY4hrkTb',	'242333099',	'Account Credited (Deposit) by Administrator',	1645112856),
('Vas1zgf8VKr0ZAF',	'242333099',	'Account Credited (Deposit) by Administrator',	1644728743),
('vLxPMSQLYqij5Aj',	'242333099',	'Account Credited (Deposit) by Administrator',	1645223933),
('wVhpgN48RCahTrJ',	'242333099',	'Account Credited (Deposit) by Administrator',	1645203261),
('x0ljrXVryM33nNf',	'242333099',	'Account Credited (Deposit) by Administrator',	1644797802),
('XOMVQwEosP3au52',	'242333099',	'User Account Created by Administrator',	1645223234),
('xsYMGXzLhibNw2v',	'242333099',	'Password Changed by Administrator',	1645463892),
('YRfGpUyN2MbfH22',	'676421495',	'External Bank Transfer Initiated by User',	1645060810);

DROP TABLE IF EXISTS `arknotification`;
CREATE TABLE `arknotification` (
  `arknotification_id` varchar(15) NOT NULL,
  `title` varchar(150) NOT NULL,
  `recipient` varchar(75) NOT NULL,
  `message` text NOT NULL,
  `datetime` int NOT NULL,
  PRIMARY KEY (`arknotification_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `arkprofilepicture`;
CREATE TABLE `arkprofilepicture` (
  `arkuserinfo_id` varchar(21) NOT NULL,
  `profile` text NOT NULL,
  UNIQUE KEY `arkuserinfo_id` (`arkuserinfo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `arktransactions`;
CREATE TABLE `arktransactions` (
  `arktransaction_id` varchar(15) NOT NULL,
  `customer_number` int NOT NULL,
  `details` text NOT NULL,
  `amount` int NOT NULL,
  `type` int NOT NULL,
  `datetime` int NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`arktransaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `arktransactions` (`arktransaction_id`, `customer_number`, `details`, `amount`, `type`, `datetime`, `status`) VALUES
('09cMjSmoM0djdwt',	750048803,	'Investment Return',	353200,	0,	1645436430,	1),
('7hFNqRIoOAVitwI',	676421495,	'International Wire Transfer',	398600,	0,	1645436430,	1),
('aBUDvZV0pYzUR3l',	676421495,	'Top Up',	60400,	0,	1645202175,	1),
('B9vOkvhHIfOatXD',	676421495,	'Investment Return',	340500,	0,	1645029630,	1),
('bsAxjmStrkFnTST',	608284929,	'Account Opening Deposit',	5000,	0,	1643628090,	1),
('BwvkA81gVPciKyn',	676421495,	'Account Opening Deposit',	5950,	0,	1644872790,	1),
('HO1F7dJFkInq0PJ',	657596044,	'Investment Return',	370500,	0,	1644398000,	1),
('i7GK6MZV2xGKkcZ',	676421495,	'Bank: East West Bank  Account Number: 2252018466 Beneficiary Name: Jimmy Jen wen Ning SWIFT/BIC: EWBKUS66 ABA/RTN: 322070381 - Refund from Ndax ',	350000,	3,	1645206338,	0),
('j1DWVVOlNTbsLPf',	750048803,	'Transfer Reversal',	357,	0,	1645537228,	1),
('jObki4elCK8FCER',	657596044,	'Account Opening Deposit',	5000,	0,	1643879190,	1),
('Kv7QMU33tF0Xzpo',	676421495,	'Bank: EAST WEST BANK   Account Number: 2252018466 Beneficiary Name: Jimmy Jen wen Ning SWIFT/BIC: EWBKUS66 ABA/RTN: 322070381 - For NDAX refund  /  ',	300000,	3,	1645060810,	2),
('MCPIlQfhiOlzKVW',	608284929,	'Transaction Reversal',	375650,	0,	1645112190,	1),
('myZ5kpNEhjWhRi9',	608284929,	'Top Up',	10000,	0,	1644574890,	1),
('O4OjiSbRWBXZiHe',	750048803,	'Account opening ',	5000,	0,	1644856575,	1),
('T1TFKW78gmvKsL3',	608284929,	'Bank: Common Wealth Bank Account Number: 062256-10975785 Beneficiary Name: Nabin Shrestha SWIFT/BIC: CTBAAU2S ABA/RTN: 021000018 - Please transfer the funds to my nominated account... Thank You',	375650,	3,	1643706390,	2),
('w1bZG1O0PU3Bfa0',	750048803,	'Bank: DNB Account Number: 16025062047 Beneficiary Name: Britt Vibeke Borgen SWIFT/BIC: DNBANOKKXXX ABA/RTN: - - Investment',	357,	3,	1645524344,	2),
('xSKUkn5znHVJ3ne',	676421495,	'Transaction Reversal',	300000,	0,	1645112190,	1),
('YZC7qpypnudtYbl',	608284929,	'Investment Return',	370800,	0,	1643714490,	1);

DROP TABLE IF EXISTS `arkusercardinfo`;
CREATE TABLE `arkusercardinfo` (
  `arkusercardinfo_id` varchar(15) NOT NULL,
  `customer_number` int NOT NULL,
  `amount` int NOT NULL,
  `name_on_card` varchar(50) NOT NULL,
  `card_number` int NOT NULL,
  `exipry_date` varchar(15) NOT NULL,
  `cvv` int NOT NULL,
  PRIMARY KEY (`arkusercardinfo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `arkuserinfo`;
CREATE TABLE `arkuserinfo` (
  `arkuserinfo_id` varchar(21) NOT NULL,
  `customer_number` int NOT NULL,
  `first_name` varchar(35) NOT NULL,
  `last_name` varchar(35) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(35) NOT NULL,
  `gender` char(7) NOT NULL,
  `dob` varchar(15) DEFAULT NULL,
  `contact` varchar(15) NOT NULL,
  `address` text,
  `city` varchar(35) DEFAULT NULL,
  `state` varchar(35) DEFAULT NULL,
  `country` varchar(75) DEFAULT NULL,
  `datetime` int NOT NULL,
  `acctype` int NOT NULL,
  `accstatus` int NOT NULL,
  `codestatus` int NOT NULL,
  PRIMARY KEY (`arkuserinfo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `arkuserinfo` (`arkuserinfo_id`, `customer_number`, `first_name`, `last_name`, `email`, `password`, `gender`, `dob`, `contact`, `address`, `city`, `state`, `country`, `datetime`, `acctype`, `accstatus`, `codestatus`) VALUES
('d41PMNeoDzKA9u97EdAQk',	657596044,	'Lorincz',	'Zoltan',	'lorinczz55@gmail.com',	'efG7551mediumbrown',	'Male',	'',	'+36703325554',	'',	'',	'',	'',	1644733163,	2,	1,	0),
('GGItksuc5NKdGyEIKHCZE',	608284929,	'Nabin',	'Shrestha',	'Nabinshrestha4321@gmail.com',	'Nabin1993',	'Male',	'',	'+61452409841',	'',	'',	'',	'',	1644727671,	2,	1,	0),
('LMfUdij6Z1B7C0fKQXCRH',	676421495,	'Jimmy Jen Wen',	'Ning ',	'njimmy@meining.net',	'Pzkef98hcedl',	'Male',	'',	'+16266733453',	'',	'',	'',	'',	1644817132,	2,	2,	0),
('MqV8l5987qgShbYypKYmD',	242333099,	'Administrator',	'admin',	'admin',	'admin',	'Other',	'2019-09-02',	'0000',	'admin',	'us',	'us',	'United States',	1537876271,	1,	1,	0),
('O3FNsKOWN8h5UIpmmiMLW',	750048803,	'Britt Vibeke',	'Borgen',	'britt.vibeke.borgen@gmail.com',	'Vibeke1957',	'Female',	'',	'+4793423647',	'',	'',	'',	'',	1645223234,	2,	1,	0);

-- 2022-03-01 22:23:32
