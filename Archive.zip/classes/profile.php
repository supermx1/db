<?php
class profilepicture
{
    public $connect;
    public $arkuserinfo_id;
    public $profile;
    
    public function __construct($arkuserinfo_id = null)
    {
        
        $connect = new PDO("mysql:host=localhost;dbname=".DB_NAME.";",DB_USERNAME,DB_PASSWORD);
		
		if(!empty($arkuserinfo_id))
			{
				$this->arkuserinfo_id = $arkuserinfo_id;
				$query = $connect->prepare("SELECT * FROM arkprofilepicture WHERE arkuserinfo_id='$this->arkuserinfo_id'");
			}
		
		$query->execute();
        foreach($query as $row)
        {
            $this->arkuserinfo_id = $row['arkuserinfo_id'];
            $this->profile = $row['profile'];
        }   
    }
}