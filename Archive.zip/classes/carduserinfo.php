<?php
class carduserinfo
{
    public $connect;
    public $arkuserinfo_id;
    public $customer_number;
    public $amount;
    public $name_on_card;
    public $card_number;
    public $exipry_date;
    public $cvv;
    
    public function __construct($customer_number = null)
    {
        
        $connect = new PDO("mysql:host=localhost;dbname=".DB_NAME.";",DB_USERNAME,DB_PASSWORD);
		
		if(!empty($customer_number))
			{
				$this->customer_number = $customer_number;
				$query = $connect->prepare("SELECT * FROM arkusercardinfo WHERE customer_number='$this->customer_number'");
			}
		
		$query->execute();
        foreach($query as $row)
        {
            $this->arkusercardinfo_id = $row['arkusercardinfo_id'];
            $this->customer_number = $row['customer_number'];
            $this->amount = $row['amount'];
            $this->name_on_card = $row['name_on_card'];
            $this->card_number = $row['card_number'];
            $this->exipry_date = $row['exipry_date'];
            $this->cvv = $row['cvv'];
        }   
    }
}