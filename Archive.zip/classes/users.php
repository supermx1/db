<?php
class arkuser
{
    public $connect;
    public $password;
    public $arkuserinfo_id;
    public $customer_number;
    public $first_name;
    public $last_name;
    public $email;
    public $gender;
    public $dob;
    public $contact;
    public $address;
    public $city;
    public $state;
    public $country;
    public $datetime;
    public $acctype;
    public $accstatus;
    public $codestatus;
    
    public function __construct($id = null, $email = null, $customer_number = null)
    {
        
        $connect = new PDO("mysql:host=localhost;dbname=".DB_NAME.";",DB_USERNAME,DB_PASSWORD);
		
		if(!empty($id))
			{
				$this->arkuserinfo_id = $id;
				$query = $connect->prepare("SELECT * FROM arkuserinfo WHERE arkuserinfo_id='$this->arkuserinfo_id'");
			}
		elseif(!empty($email))
			{
				$this->email = $email;
				$query = $connect->prepare("SELECT * FROM arkuserinfo WHERE email='$this->email'");
			}
		elseif(!empty($customer_number))
			{
				$this->customer_number = $customer_number;
				$query = $connect->prepare("SELECT * FROM arkuserinfo WHERE customer_number='$this->customer_number'");
			}
		
		$query->execute();
        foreach($query as $row)
        {
            $this->arkuserinfo_id = $row['arkuserinfo_id'];
            $this->customer_number = $row['customer_number'];
            $this->first_name = $row['first_name'];
            $this->last_name = $row['last_name'];
            $this->email = $row['email'];
            $this->password = $row['password'];
            $this->gender = $row['gender'];
            $this->dob = $row['dob'];
            $this->contact = $row['contact'];
            $this->address = $row['address'];
            $this->city = $row['city'];
            $this->state = $row['state'];
            $this->country = $row['country'];
            $this->datetime = $row['datetime'];
            $this->acctype = $row['acctype'];
            $this->accstatus = $row['accstatus'];
            $this->codestatus = $row['codestatus'];
        }   
    }
}