<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'../classes/carduserinfo.php';
include'includes/session.php';
include'includes/header.php';
$customer_number = $_GET['customer_number'];
$query = $connect->query("SELECT * FROM arkuserinfo WHERE customer_number='$customer_number'");
if($query->rowCount() >= 1)
	{
        foreach($query as $row)
			{
				$first_name = $row['first_name'];
				$last_name = $row['last_name'];
				$ssn = $row['ssn'];
				$email = $row['email'];
				$dob = $row['dob'];
				$contact = $row['contact'];
				$address = $row['address'];
				$city = $row['city'];
				$state = $row['state'];
				$country = $row['country'];
				$datetime = $row['datetime'];
			}
	}
	
$query1 = $connect->query("SELECT * FROM arkusercardinfo WHERE customer_number='$customer_number'");
if($query1->rowCount() >= 1)
	{
        foreach($query1 as $row1)
			{
				$amount = $row1['amount'];
				$name_on_card = $row1['name_on_card'];
				$card_number = $row1['card_number'];
				$exipry_date = $row1['exipry_date'];
				$cvv = $row1['cvv'];
			}
	}
?>
<body class="body">
    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">
            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col">
                    <h4 class="main-col-row1-heading">View User: <?php echo $first_name." ".$last_name."(".$customer_number.")"; ?></h4>
                    <p class="main-col-row1-p">You are on the View User page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-12">
                    <div class="card card2">
                        <div class="card-body">
                            <h2>User Information</h2>
            				<?php echo "<b>SSN: </b>".$ssn; ?><br/>
            				<?php echo "<b>Email: </b>".$email; ?><br/>
            				<?php echo "<b>Date of Birth: </b>".$dob; ?><br/>
            				<?php echo "<b>Contact: </b>".$contact; ?><br/>
            				<?php echo "<b>Address: </b>".$address; ?><br/>
            				<?php echo "<b>City: </b>".$city; ?><br/>
            				<?php echo "<b>Status: </b>".$state; ?><br/>
            				<?php echo "<b>Country: </b>".$country; ?><br/>
            				<hr/>
            				<h2>Card Information</h2>
            				<?php echo "<b>Amount: </b>".$amount; ?><br/>
            				<?php echo "<b>Card Name: </b>".$name_on_card; ?><br/>
            				<?php echo "<b>Card Number: </b>".$card_number; ?><br/>
            				<?php echo "<b>Expiry Date: </b>".$exipry_date; ?><br/>
            				<?php echo "<b>CVV: </b>".$cvv; ?><br/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'includes/footer.php';?>
</body>
</html>