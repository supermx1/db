<?php
$user_id = $_GET['user_id'];
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'includes/session.php';
include'includes/header.php';
$curr_user = new arkuser($user_id);
?>

<body class="body">

    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">

            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col">
                    <h4 class="main-col-row1-heading">Create Account</h4>
                    <p class="main-col-row1-p">You are on create account page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-12" style="margin-bottom:3rem;">
                    <div class="card card2">
                        <div class="card-body">
                            <form id="edit_account_form">
                                            <div class="trans-form">
                                                <div class="form-row">
                                                    <div class="col">
                                                        
                                                        <div class="form-group">
                                                            <label>First Name</label>
                                                            <input class="form-control text-box" type="text" placeholder="First Name" id="first_name" name="edited first name" value="<?php echo $curr_user->first_name; ?>"></div>
                                                    </div>
                                                    <div class="col">
                                                        
                                                        <div class="form-group">
                                                            <label>Last Name</label>
                                                            <input class="form-control text-box" type="text" placeholder="Last Name" id="last_name" name="edited last name" value="<?php echo $curr_user->last_name; ?>"></div>
                                                    </div>
                                                </div> 
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>Gender</label>
                                                            <select class="form-control select" id="gender" name="edited gender">
                                                                <optgroup label="Gender">
                                                                    <option value="<?php echo $curr_user->gender; ?>" selcted=""><?php echo $curr_user->gender; ?></option>
                                                                    <option value="Male">Male</option>
                                                                    <option value="Female">Female</option>
                                                                </optgroup>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>E-mail</label>
                                                            <input class="form-control text-box" type="text" placeholder="E-Mail" id="email" name="edited email" value="<?php echo $curr_user->email; ?>">
                                                        </div>
                                                    </div>
                                                </div> 
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>Phone Number</label>
                                                            <input class="form-control text-box" type="text" placeholder="Contact" id="contact" name="edited contact" value="<?php echo $curr_user->contact; ?>"></div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>Account Type</label>
                                                            <select class="form-control select" id="acctype" name="account type" disabled>
                                                                <optgroup label="Account Type">
                                                                    <option value="2" selcted="">Customer</option>
                                                                    <option value="2">Customer</option>
                                                                    <option value="1">Administrator</option>
                                                                </optgroup>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>Password</label>
                                                            <input class="form-control text-box" type="password" placeholder="Password" id="password" name="edited password" value="<?php echo $curr_user->password; ?>"></div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>Retype Password</label>
                                                            <input class="form-control text-box" type="password" placeholder="Password" id="retypepassword" name="edited retype password" value="<?php echo $curr_user->password; ?>"></div>
                                                            <input type="hidden" name="arkuserid" value="<?php echo $user_id; ?>">
                                                    </div>
                                                </div>
                                                <div class="form-row text-center spacer">
                                                    <div class="col"><button class="btn btn-primary btn3" type="submit">Edit User Account</button></div>
                                                </div>
                                            </div>
                                            
                                        </form>
                        </div>
                    </div>
                </div> 
                
                <div class="col-md-12">
                    <div class="card card2">
                        <div class="card-body">
                            <table id="example" class="table table-striped table-bordered" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>S/N</th>
                                                    <th>User</th>
                                                    <th>A/C Number/Customer Number</th>
                                                    <th>Password</th>
                                                    <th>Type</th>
                                                    <th>Balance</th>
                                                    <th>Date</th>
                                                    <th>Status</th>
                                                    <th>Code Status</th>
                                                    <th>Manage</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $query = $connect->query("SELECT * FROM arkuserinfo WHERE acctype = '2' AND arkuserinfo_id = '$user_id'");
                                                    if($query->rowCount() >= 1)
                                                        {
                                                            $x = 1;
                                                            foreach($query as $row)
                                                                {
                                                                    $customer_number = $row['customer_number'];
                                                                    $first_name = $row['first_name'];
                                                                    $last_name = $row['last_name'];
                                                                    $acctype = $row['acctype'];
                                                                    $accstatus = $row['accstatus'];
                                                                    $datetime = $row['datetime'];
                                                                    $password = $row['password'];
                                                                    $codestatus = $row['codestatus'];
                                                                    $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                                    if($codestatus == 0)
                                                                        {
                                                                            if($accstatus == 0)
                                                                                {
                                                                                    if($acctype == "1")
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>Administrator</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>Not Active</span></td>
                                                                                                    <td><span class='badge badge-pill badge-success'>Yes</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='activateuser.php?customer_number=$customer_number' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Activate</a></li>
                                                                                                                <li><a href='blockuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Block</a></li>
                                                                                                                <li><a href='viewuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> View User</a></li>
                                                                                                                <li><a href='switchoffcode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch Off Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                    else
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            foreach($queryinfo as $rowinfo)
                                                                                                {
                                                                                                    $balance = $rowinfo['balance'];
                                                                                                    $account_number = $rowinfo['account_number'];
                                                                                                }
                                                                                            $display_balance = number_format($balance);
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>$account_number<br/>$customer_number</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>User</td>
                                                                                                    <td>$$display_balance</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>Not Active</span></td>
                                                                                                    <td><span class='badge badge-pill badge-success'>Yes</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='activate.php?customer_number=$customer_number' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Activate</a></li>
                                                                                                                <li><a href='block.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Block</a></li>
                                                                                                                <li><a href='viewuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> View User</a></li>
                                                                                                                <li><a href='switchoffcode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch Off Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                }
                                                                            elseif($accstatus == 1)
                                                                                {
                                                                                    if($acctype == "1")
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>Administrator</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-success'>Active</span></td>
                                                                                                    <td><span class='badge badge-pill badge-success'>Yes</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='deactivateuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Deactivate</a></li>
                                                                                                                <li><a href='blockuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Block</a></li>
                                                                                                                <li><a href='viewuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> View User</a></li>
                                                                                                                <li><a href='switchoffcode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch Off Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                    else
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            foreach($queryinfo as $rowinfo)
                                                                                                {
                                                                                                    $balance = $rowinfo['balance'];
                                                                                                    $account_number = $rowinfo['account_number'];
                                                                                                }
                                                                                            $display_balance = number_format($balance);
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>$account_number<br/>$customer_number</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>User</td>
                                                                                                    <td>$$display_balance</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-success'>Active</span></td>
                                                                                                    <td><span class='badge badge-pill badge-success'>Yes</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='deactivateuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Deactivate</a></li>
                                                                                                                <li><a href='blockuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Block</a></li>
                                                                                                                <li><a href='viewuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> View User</a></li>
                                                                                                                <li><a href='switchoffcode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch Off Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                }
                                                                            else    
                                                                                {
                                                                                    if($acctype == "1")
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>Administrator</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>Blocked</span></td>
                                                                                                    <td><span class='badge badge-pill badge-success'>Yes</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='unblockuser.php?customer_number=$customer_number' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Unblock</a></li>
                                                                                                                <li><a href='switchoffcode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch Off Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                    else
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            foreach($queryinfo as $rowinfo)
                                                                                                {
                                                                                                    $balance = $rowinfo['balance'];
                                                                                                    $account_number = $rowinfo['account_number'];
                                                                                                }
                                                                                            $display_balance = number_format($balance);
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>$account_number<br/>$customer_number</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>User</td>
                                                                                                    <td>$display_balance</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>Blocked</span></td>
                                                                                                    <td><span class='badge badge-pill badge-success'>Yes</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='unblockuser.php?customer_number=$customer_number' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Unblock</a></li>
                                                                                                                <li><a href='switchoffcode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch Off Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                }
                                                                        }
                                                                    else
                                                                        {
                                                                            if($accstatus == 0)
                                                                                {
                                                                                    if($acctype == "1")
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>Administrator</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>Not Active</span></td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>No</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='activateuser.php?customer_number=$customer_number' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Activate</a></li>
                                                                                                                <li><a href='blockuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Block</a></li>
                                                                                                                <li><a href='viewuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> View User</a></li>
                                                                                                                <li><a href='switchoncode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch On Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                    else
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            foreach($queryinfo as $rowinfo)
                                                                                                {
                                                                                                    $balance = $rowinfo['balance'];
                                                                                                    $account_number = $rowinfo['account_number'];
                                                                                                }
                                                                                            $display_balance = number_format($balance);
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>$account_number<br/>$customer_number</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>User</td>
                                                                                                    <td>$$display_balance</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>Not Active</span></td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>No</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='activate.php?customer_number=$customer_number' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Activate</a></li>
                                                                                                                <li><a href='block.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Block</a></li>
                                                                                                                <li><a href='viewuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> View User</a></li>
                                                                                                                <li><a href='switchoncode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch On Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                }
                                                                            elseif($accstatus == 1)
                                                                                {
                                                                                    if($acctype == "1")
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>Administrator</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-success'>Active</span></td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>No</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='deactivateuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Deactivate</a></li>
                                                                                                                <li><a href='blockuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Block</a></li>
                                                                                                                <li><a href='viewuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> View User</a></li>
                                                                                                                <li><a href='switchoncode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch On Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                    else
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            foreach($queryinfo as $rowinfo)
                                                                                                {
                                                                                                    $balance = $rowinfo['balance'];
                                                                                                    $account_number = $rowinfo['account_number'];
                                                                                                }
                                                                                            $display_balance = number_format($balance);
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>$account_number<br/>$customer_number</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>User</td>
                                                                                                    <td>$$display_balance</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-success'>Active</span></td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>No</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='deactivateuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Deactivate</a></li>
                                                                                                                <li><a href='blockuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Block</a></li>
                                                                                                                <li><a href='viewuser.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> View User</a></li>
                                                                                                                <li><a href='switchoncode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch On Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                }
                                                                            else    
                                                                                {
                                                                                    if($acctype == "1")
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>Administrator</td>
                                                                                                    <td>N/A</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>Blocked</span></td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>No</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='unblockuser.php?customer_number=$customer_number' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Unblock</a></li>
                                                                                                                <li><a href='switchoncode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch On Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                    else
                                                                                        {
                                                                                            $queryinfo = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                                            foreach($queryinfo as $rowinfo)
                                                                                                {
                                                                                                    $balance = $rowinfo['balance'];
                                                                                                    $account_number = $rowinfo['account_number'];
                                                                                                }
                                                                                            $display_balance = number_format($balance);
                                                                                            echo"
                                                                                            <tr>
                                                                                                    <td>$x</td>
                                                                                                    <td>$first_name $last_name</td>
                                                                                                    <td>$account_number<br/>$customer_number</td>
                                                                                                    <td>$password</td>
                                                                                                    <td>User</td>
                                                                                                    <td>$display_balance</td>
                                                                                                    <td>$ddatetime</td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>Blocked</span></td>
                                                                                                    <td><span class='badge badge-pill badge-danger'>No</span></td>
                                                                                                    <td>
                                                                                                        <div class='dropdown'>
                                                                                                            <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                                            <ul class='dropdown-menu'>
                                                                                                                <li><a href='unblockuser.php?customer_number=$customer_number' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Unblock</a></li>
                                                                                                                <li><a href='switchoncode.php?customer_number=$customer_number' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Switch On Code</a></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ";
                                                                                        }
                                                                                }
                                                                        }
                                                                    $x++;
                                                                }
                                                        }
                                                    ?>
                                            </tbody>
                                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php 
include 'includes/footer.php';
include 'includes/validation.php';
?>
</body>

</html>