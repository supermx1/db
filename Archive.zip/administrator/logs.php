<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'includes/session.php';
include'includes/header.php';
?>
<body class="body">
    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">
            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col">
                    <h4 class="main-col-row1-heading">Logs</h4>
                    <p class="main-col-row1-p">You are on logs page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-12">
                    <div class="card card2">
                        <div class="card-body">
                            <table id="example" class="table table-striped table-bordered" width="100%">
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>User</th>
                                        <th>Activity</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $query = $connect->query("SELECT * FROM arklog");
                                        if($query->rowCount() >= 1)
                                            {
                                                $x = 1;
                                                foreach($query as $row)
                                                    {
                                                        $arklog_id = $row['arklog_id'];
                                                        $user_id = $row['user_id'];
                                                        $description = $row['description'];
                                                        $datetime = $row['datetime'];
                                                        $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                        $current_arkuser = new arkuser('','',$user_id);
                                                        echo"
                                                        <tr>
                                                            <td>$x</td>
                                                            <td>$current_arkuser->first_name $current_arkuser->last_name</td>
                                                            <td>$description</td>
                                                            <td>$ddatetime</td>
                                                        </tr>
                                                        ";      
                                                        $x++;
                                                    }
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'includes/footer.php';?>
</body>
</html>