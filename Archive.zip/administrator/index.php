<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'includes/session.php';
include'includes/header.php';
include'../settings.php';

$querycustomer = $connect->query("SELECT * FROM arkuserinfo WHERE acctype = '2'");
$customercount = $querycustomer->rowCount();

$queryadministrator = $connect->query("SELECT * FROM arkuserinfo WHERE acctype = '1'");
$administratorcount = $queryadministrator->rowCount();

$queryarklog = $connect->query("SELECT * FROM arklog");
$arklogcount = $queryarklog->rowCount();

$querytransaction = $connect->query("SELECT * FROM arktransactions");
$transactioncount = $querytransaction->rowCount();

$querycardrequests = $connect->query("SELECT * FROM arkcardrequest");
$cardrequestcount = $querycardrequests->rowCount();
?>

<body class="body">
    <?php include 'includes/nav.php';?>

    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">
            <?php include 'includes/sidebar.php';?>

        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col">
                    <h4 class="main-col-row1-heading">Dashboard</h4>
                    <p class="main-col-row1-p">You are on the dashboard page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-sm-3">
                    <div class="card card2 hover">
                        <div class="card-body">
                            <p class="text-right admin-p">Customers</p>
                            <h6 class="pull-left"><i class="la la-users icon1"></i></h6>
                            <h3 class="text-right admin-heading"><?php echo $customercount; ?></h3>
                            <p class="text-right admin-p2">Total Number of Customers</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="card card2 hover">
                        <div class="card-body">
                            <p class="text-right admin-p">Transactions</p>
                            <h6 class="pull-left"><i class="la la-bar-chart icon1"></i></h6>
                            <h3 class="text-right admin-heading"><?php echo $transactioncount; ?></h3>
                            <p class="text-right admin-p2">Total Number of TX</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="card card2 hover">
                        <div class="card-body">
                            <p class="text-right admin-p">Cards</p>
                            <h6 class="pull-left"><i class="la la-credit-card icon1"></i></h6>
                            <h3 class="text-right admin-heading"><?php echo $cardrequestcount; ?></h3>
                            <p class="text-right admin-p2">Card Requests</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="card card2 hover">
                        <div class="card-body">
                            <p class="text-right admin-p">Logs</p>
                            <h6 class="pull-left"><i class="la la-info icon1"></i></h6>
                            <h3 class="text-right admin-heading"><?php echo $arklogcount; ?></h3>
                            <p class="text-right admin-p2">Log Count</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row" id="row3">
                <div class="col-md-12 row3-col">
                    <h6 class="dashboard-p"><i class="icon-pie-chart menu-item-icon"></i>Recent Operations</h6>
                    <div class="card card2">
                        <div class="card-body">
                            <div>
                                <ul class="nav nav-pills">
                                    <li class="nav-item mr-2
                                    "><a class="nav-link active link2" role="tab" data-toggle="pill" href="#tab-4">Transfers</a></li>
                                    <li class="nav-item"><a class="nav-link link2" role="tab" data-toggle="pill" href="#tab-5">Card Requests</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" role="tabpanel" id="tab-4">
                                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>S/N</th>
                                                        <th>Ref. Number</th>
                                                        <th>Date</th>
                                                        <th>Account No.</th>
                                                        <th>Amount</th>
                                                        <th>Type</th>
                                                        <th>V.Code</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $query = $connect->query("SELECT * FROM arktransactions WHERE type = '3'");
                                                    if($query->rowCount() >= 1)
                                                        {
                                                            $x = 1;
                                                            foreach($query as $row)
                                                                {
                                                                    $arktransaction_id = $row['arktransaction_id'];
                                                                    $details = $row['details'];
                                                                    $amount = $row['amount'];
                                                                    $status = $row['status'];
                                                                    $query1 = $connect->query("SELECT * FROM arkexttransfercode WHERE arkexttransfercode_id = '$arktransaction_id'");
                                                                    foreach($query1 as $row1)
                                                                        {
                                                                            $code = $row1['code'];
                                                                            $code1 = $row1['code1'];
                                                                            $code2 = $row1['code2'];
                                                                            $code3 = $row1['code3'];
                                                                            $code4 = $row1['code4'];
                                                                        }
                                                                    $display_amount = number_format($amount);
                                                                    $type = $row['type']; 
                                                                    $customer_number = $row['customer_number']; 
                                                                    $curr_user = new arkuser('','',$customer_number);
                                                                    $query2 = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                    foreach($query2 as $row2)
                                                                        {
                                                                            $account_number = $row2['account_number'];
                                                                        }
                                                                    $datetime = $row['datetime'];
                                                                    $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                                    if($status == 0)
                                                                        {
                                                                            $display_status = "<span class='badge badge-pill badge-info'>Pending</span>";
                                                                        }
                                                                    elseif($status == 1)
                                                                        {
                                                                            $display_status = "<span class='badge badge-pill badge-success'>Successful</span>";
                                                                        }
                                                                    else
                                                                        {
                                                                            $display_status = "<span class='badge badge-pill badge-danger'>Canceled</span>";
                                                                        }
                                                                    echo"
                                                                    <tr>
                                                                        <td>$x</td>
                                                                        <td>$arktransaction_id</td>
                                                                        <td>$ddatetime</td>
                                                                        <td>$account_number (USD)<br /><small>$curr_user->first_name $curr_user->last_name </small></td>
                                                                        <td>$symbol$display_amount</td>
                                                                        <td>External Funds Transfer</td>
                                                                        <td>V1:$code<br/>V2:$code1<br/>V3:$code2<br/>V4:$code3<br/>V5:$code4</td>
                                                                        <td>$display_status</td>
                                                                    </tr>
                                                                    ";
                                                                    $x++;
                                                                }
                                                        }
                                                    
                                                    ?>
                                                </tbody>
                                            </table>
                                    </div>
                                    <div class="tab-pane fade" role="tabpanel" id="tab-5">
                                        <table id="example1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>S/N</th>
                                                        <th>Name</th>
                                                        <th>Date Ordered</th>
                                                        <th>Type</th>
                                                        <th>Account</th>
                                                        <th>Status</th>
                                                        <th>Manage</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $query = $connect->query("SELECT * FROM arkcardrequest");
                                                    if($query->rowCount() >= 1)
                                                        {
                                                            $x = 1;
                                                            foreach($query as $row)
                                                                {
                                                                    $arkcardrequest_id = $row['arkcardrequest_id'];
                                                                    $cardtype = $row['cardtype'];
                                                                    $instruction = $row['instruction'];
                                                                    $customer_number = $row['customer_number'];
                                                                    $curr_user = new arkuser('','',$customer_number);
                                                                    $status = $row['status'];
                                                                    $datetime = $row['datetime'];
                                                                    $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                                    if($status == 0)
                                                                        {
                                                                            echo"
                                                                            <tr>
                                                                                <td>$x</td>
                                                                                <td>$curr_user->first_name $curr_user->last_name</td>
                                                                                <td>$ddatetime</td>
                                                                                <td>$cardtype</td>
                                                                                <td>USD ($)</td>
                                                                                <td><span class='badge badge-pill badge-info'>Pending</span></td>
                                                                                <td>
                                                                                    <div class='dropdown'> 
                                                                                        <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Action <span class=''></span></button>
                                                                                        <ul class='dropdown-menu'>
                                                                                            <li><a href='cancelcard.php?cardrequest_id=$eescardrequest_id' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Cancel Card</a></li>
                                                                                            <li><a href='approvecard.php?cardrequest_id=$arkcardrequest_id' class='nav-link dropdown-item'><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Approve Card</a></li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </td>
                                                                            </tr>
                                                                            ";
                                                                        }
                                                                    elseif($status == 1)
                                                                        {
                                                                            echo"
                                                                            <tr>
                                                                                <td>$x</td>
                                                                                <td>$curr_user->first_name $curr_user->last_name</td>
                                                                                <td>$ddatetime</td>
                                                                                <td>$cardtype</td>
                                                                                <td>USD ($)</td>
                                                                                <td><span class='badge badge-pill badge-success'>Success</span></td>
                                                                                <td>
                                                                                    <div class='dropdown'> 
                                                                                        <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Action <span class=''></span></button>
                                                                                        <ul class='dropdown-menu'>
                                                                                            <li><a href='cancelcard.php?cardrequest_id=$arkcardrequest_id' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Cancel Card</a></li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </td>
                                                                            </tr>
                                                                            ";
                                                                        }
                                                                    else
                                                                        {
                                                                            echo"
                                                                            <tr>
                                                                                <td>$x</td>
                                                                                <td>$curr_user->first_name $curr_user->last_name</td>
                                                                                <td>$ddatetime</td>
                                                                                <td>$cardtype</td>
                                                                                <td>$currency ($symbol)</td>
                                                                                <td><span class='badge badge-pill badge-danger'>Canceled</span></td>
                                                                                <td>N/A</td>
                                                                            </tr>
                                                                            ";
                                                                        }
                                                                }
                                                        }
                                                    ?>
                                                </tbody>
                                            </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include 'includes/footer.php';?>
</body>
</html>