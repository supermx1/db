<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'includes/session.php';
include'includes/header.php';
include'../settings.php';
?>
<body class="body">
    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">

            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col">
                    <h4 class="main-col-row1-heading">Transfers</h4>
                    <p class="main-col-row1-p">You are on transfers page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-12">
                    <div class="card card2">
                        <div class="card-body">
                            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Ref. Number</th>
                                        <th>Date</th>
                                        <th>Account No.</th>
                                        <th>Amount</th>
                                        <th>Type</th>
                                        <th>V.Code</th>
                                        <th>Status</th>
                                        <th>Manage</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                                    $query = $connect->query("SELECT * FROM arktransactions WHERE type = '3'");
                                                    if($query->rowCount() >= 1)
                                                        {
                                                            $x = 1;
                                                            foreach($query as $row)
                                                                {
                                                                    $arktransaction_id = $row['arktransaction_id'];
                                                                    $details = $row['details'];
                                                                    $amount = $row['amount'];
                                                                    $status = $row['status'];
                                                                    $query1 = $connect->query("SELECT * FROM arkexttransfercode WHERE arkexttransfercode_id = '$arktransaction_id'");
                                                                    foreach($query1 as $row1)
                                                                        {
                                                                            $code = $row1['code'];
                                                                            $code1 = $row1['code1'];
                                                                            $code2 = $row1['code2'];
                                                                            $code3 = $row1['code3'];
                                                                            $code4 = $row1['code4'];
                                                                        }
                                                                    $display_amount = number_format($amount);
                                                                    $type = $row['type']; 
                                                                    $customer_number = $row['customer_number']; 
                                                                    $curr_user = new arkuser('','',$customer_number);
                                                                    $query2 = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$customer_number'");
                                                                    foreach($query2 as $row2)
                                                                        {
                                                                            $account_number = $row2['account_number'];
                                                                        }
                                                                    $datetime = $row['datetime'];
                                                                    $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                                    if($status == 0)
                                                                        {
                                                                            $display_status = "<span class='badge badge-pill badge-info'>Pending</span>";
                                                                            echo"
                                                                            <tr>
                                                                                <td>$x</td>
                                                                                <td>$arktransaction_id</td>
                                                                                <td>$ddatetime</td>
                                                                                <td>$account_number (USD)<br /><small>$curr_user->first_name $curr_user->last_name </small></td>
                                                                                <td>$symbol$display_amount</td>
                                                                                <td>External Funds Transfer</td>
                                                                                <td>V1:$code<br/>V2:$code1<br/>V3:$code2<br/>V4:$code3<br/>V5:$code4</td>
                                                                                <td>$display_status</td>
                                                                                <td>
                                                                                    <div class='dropdown'>
                                                                                        <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                        <ul class='dropdown-menu'>
                                                                                            <li><a href='approvetransaction.php?transaction_id=$arktransaction_id' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Approve</a></li>
                                                                                            <li><a href='canceltransaction.php?transaction_id=$arktransaction_id' class='nav-link dropdown-item''><i class='icon ion-android-cancel dropdown-icon'></i> Cancel</a></li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </td>
                                                                            </tr>
                                                                            ";
                                                                        }
                                                                    elseif($status == 1)
                                                                        {
                                                                            $display_status = "<span class='badge badge-pill badge-success'>Successful</span>";
                                                                            echo"
                                                                            <tr>
                                                                                <td>$x</td>
                                                                                <td>$arktransaction_id</td>
                                                                                <td>$ddatetime</td>
                                                                                <td>$account_number (USD)<br /><small>$curr_user->first_name $curr_user->last_name </small></td>
                                                                                <td>$symbol$display_amount</td>
                                                                                <td>External Funds Transfer</td>
                                                                                <td>V1:$code<br/>V2:$code1<br/>V3:$code2</td>
                                                                                <td>$display_status</td>
                                                                                <td>
                                                                                    <div class='dropdown'>
                                                                                        <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                        <ul class='dropdown-menu'>
                                                                                            <li><a href='canceltransaction.php?transaction_id=$arktransaction_id' class='nav-link dropdown-item''><i class='icon ion-android-cancel dropdown-icon'></i> Cancel</a></li>
                                                                                            <li><a href='pendingtransaction.php?transaction_id=$arktransaction_id' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Pending</a></li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </td>
                                                                            </tr>
                                                                            ";
                                                                        }
                                                                    else
                                                                        {
                                                                            $display_status = "<span class='badge badge-pill badge-danger'>Canceled</span>";
                                                                            echo"
                                                                            <tr>
                                                                                <td>$x</td>
                                                                                <td>$arktransaction_id</td>
                                                                                <td>$ddatetime</td>
                                                                                <td>$account_number (USD)<br /><small>$curr_user->first_name $curr_user->last_name </small></td>
                                                                                <td>$symbol$display_amount</td>
                                                                                <td>External Funds Transfer</td>
                                                                                <td>V1:$code<br/>V2:$code1<br/>V3:$code2</td>
                                                                                <td>$display_status</td>
                                                                                <td>
                                                                                    <div class='dropdown'>
                                                                                        <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Manage<span></span></button>
                                                                                        <ul class='dropdown-menu'>
                                                                                            <li><a href='approvetransaction.php?transaction_id=$arktransaction_id' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Approve</a></li>
                                                                                            <li><a href='pendingtransaction.php?transaction_id=$arktransaction_id' class='nav-link dropdown-item''><i class='icon ion-android-checkmark-circle dropdown-icon'></i> Pending</a></li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </td>
                                                                            </tr>
                                                                            ";
                                                                        }
                                                                    
                                                                    $x++;
                                                                }
                                                        }
                                                    
                                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'includes/footer.php';?>
</body>

</html>