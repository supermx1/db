<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'includes/session.php';
include'includes/header.php';
?>
<body class="body">
    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">
            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col">
                    <h4 class="main-col-row1-heading">Fund Account</h4>
                    <p class="main-col-row1-p">You are on fund account page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-8">
                    <div class="card card2">
                        <div class="card-body">
                            <form id="fund_account">
                                <div class="trans-form">
                                    <div class="form-row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Account Number or Customer Number</label>
                                                <input class="form-control text-box" type="text" id="accountnumber" name="account number" placeholder="Account Number or Customer Number"></div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Amount to Transfer</label>
                                                <input class="form-control text-box" type="number" id="amount" name="amount" placeholder="Amount to Transfer"></div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Epoch Time</label> | <small>Used to backdate transactions</small> 
                                                <input class="form-control text-box" type="number" id="epochtime" name="epochtime" placeholder="Epoch Time">
                                            <small><a href="https://www.unixtimestamp.com/" target="blank_">Get Epoch Time (Transaction Time/Date)</a></small>   
                                                </div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label>Transaction Details</label>
                                                <textarea class="form-control text-box" rows="3" id="transactiondetails" name="transaction details" placeholder="Transaction Details"></textarea></div>
                                        </div>
                                    </div>
                                    <div class="form-row text-center spacer">
                                        <div class="col">
                                            <div class="form-group"><button class="btn btn-primary btn3" type="submit">Fund Account</button></div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php 
include 'includes/footer.php';
include 'includes/validation.php';
?>
</body>
</html>