<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'includes/session.php';
include'includes/header.php';
?>
<body class="body">
    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">
            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col">
                    <h4 class="main-col-row1-heading">Notifications &amp; More</h4>
                    <p class="main-col-row1-p">You are on notifications &amp; more page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-12">
                    <div class="card card2">
                        <div class="card-body">
                            <div>
                                <ul class="nav nav-pills">
                                    <li class="nav-item"><a class="nav-link active link2" role="tab" data-toggle="pill" href="#tab-4">Notifications</a></li>
                                    <li class="nav-item"><a class="nav-link link2" role="tab" data-toggle="pill" href="#tab-5">HTML E-Mails</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" role="tabpanel" id="tab-4">
                                        <form id="create_notification">
                                            <div class="trans-form">
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" id="title" name="title" placeholder="Notification Title"></div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" id="recipient" name="recipient" placeholder="Recipient (Leave blank to send to all customers)"></div>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group"><textarea class="form-control text-box" rows="6" id="message" name="message" placeholder="Notification Message"></textarea></div>
                                                    </div>
                                                </div>
                                                <div class="form-row text-center spacer">
                                                    <div class="col">
                                                        <div class="form-group"><button class="btn btn-primary btn3" type="submit">Send Notification</button></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                        <div class="table-div mt-4">
                                            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>S/N</th>
                                                        <th>Message Title</th>
                                                        <th>Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        $query = $connect->query("SELECT * FROM arknotification");
                                                        if($query->rowCount() >= 1)
                                                            {
                                                                $x = 1;
                                                                foreach($query as $row)
                                                                    {
                                                                        $arknotification_id = $row['arknotification_id'];
                                                                        $message = $row['message'];
                                                                        $title = $row['title'];
                                                                        $datetime = $row['datetime'];
                                                                        $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                                        echo"
                                                                        <tr>
                                                                            <td>$x</td>
                                                                            <td>$title</td>
                                                                            <td>$ddatetime</td>
                                                                        </tr>
                                                                        ";
                                                                    }
                                                            }
                                                        ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" role="tabpanel" id="tab-5">
                                        <form id="send_htmlmail">
                                            <div class="trans-form">
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" id="subject" name="subject" placeholder="E-Mail Subject"></div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" id="htmlrecipient" name="recipient" placeholder="Recipient E-Mail (Leave blank to send to all customers)"></div>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group"><textarea class="form-control text-box" rows="6" id="htmlmessage" name="html message" placeholder="E-Mail Message"></textarea></div>
                                                    </div>
                                                </div>
                                                <div class="form-row text-center spacer">
                                                    <div class="col">
                                                        <div class="form-group"><button class="btn btn-primary btn3" type="submit">Send E-Mail</button></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                        <div class="table-div mt-4">
                                            <table id="example1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>S/N</th>
                                                        <th>Subject</th>
                                                        <th>Message</th>
                                                        <th>Recepient</th>
                                                        <th>Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        $query = $connect->query("SELECT * FROM arkhtmlmail");
                                                        if($query->rowCount() >= 1)
                                                            {
                                                                $x = 1;
                                                                foreach($query as $row)
                                                                    {
                                                                        $arkhtmlmail_id = $row['arkhtmlmail_id'];
                                                                        $subject = $row['subject'];
                                                                        $recepient = $row['recepient'];
                                                                        $mailcontent = $row['mailcontent'];
                                                                        $datetime = $row['datetime'];
                                                                        $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                                        echo"
                                                                        <tr>
                                                                            <td>$x</td>
                                                                            <td>$subject</td>
                                                                            <td>$mailcontent</td>
                                                                            <td>$recepient</td>
                                                                            <td>$ddatetime</td>
                                                                        </tr>
                                                                        ";
                                                                    }
                                                            }
                                                        ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php 
include 'includes/footer.php';
include 'includes/validation.php';
?>
</body>
</html>