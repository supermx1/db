<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'includes/session.php';
$transaction_id = $_GET['transaction_id'];
$query = $connect->query("UPDATE arktransactions SET status = '1' WHERE arktransaction_id = '$transaction_id'");
echo"<meta http-equiv='refresh' content='0;url=index.php'>";
?>