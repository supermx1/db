<?php include 'includes/header.php';?>

<body class="body">

    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">

            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col">
                    <h4 class="main-col-row1-heading">View Details</h4>
                    <p class="main-col-row1-p">Reference Number: 23123446678</p>
                </div>
            </div>
            <div class="row" id="row3">
                <div class="col-md-12 row3-col">
                    <div class="card card2">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <tbody>
                                        <tr>
                                            <td>Date</td>
                                            <td>3 January, 2018</td>
                                        </tr>
                                        <tr>
                                            <td>Account Number</td>
                                            <td>2134567890 (USD)<br>Francis Underwood</td>
                                        </tr>
                                        <tr>
                                            <td>Amount</td>
                                            <td>$4,400,000</td>
                                        </tr>
                                        <tr>
                                            <td>Type</td>
                                            <td>External Bank</td>
                                        </tr>
                                        <tr>
                                            <td>V.Codes</td>
                                            <td>123456, 456789, 098765</td>
                                        </tr>
                                        <tr>
                                            <td>Status</td>
                                            <td><span class="badge badge-pill badge-primary">Processing</span></td>
                                        </tr>
                                        <tr>
                                            <td>Beneficiary Name</td>
                                            <td>John Wick</td>
                                        </tr>
                                        <tr>
                                            <td>Beneficiary Account Number</td>
                                            <td>340909219213</td>
                                        </tr>
                                        <tr>
                                            <td>Beneficiary Bank</td>
                                            <td>Bank of America</td>
                                        </tr>
                                        <tr>
                                            <td>SWIFT/BIC</td>
                                            <td>1324213</td>
                                        </tr>
                                        <tr>
                                            <td>ABA/RTN</td>
                                            <td>213241</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'includes/footer.php';?>
</body>

</html>
