<?php 
$config = parse_ini_file("../../config.ini");
include'includes/connect.php';
session_destroy();
echo"<meta http-equiv='refresh' content='0;url=../index.php'>";
?>