<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'includes/session.php';
$cardrequest_id = $_GET['cardrequest_id'];
$query = $connect->query("UPDATE arkcardrequest SET status = '2' WHERE arkcardrequest_id = '$cardrequest_id'");
echo"<meta http-equiv='refresh' content='0;url=index.php'>";
?>