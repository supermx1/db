<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'includes/session.php';
$customer_number = $_GET['customer_number'];
$query = $connect->query("UPDATE arkuserinfo SET accstatus = '1' WHERE customer_number = '$customer_number'");
echo"<meta http-equiv='refresh' content='0;url=create-account.php'>";
?>