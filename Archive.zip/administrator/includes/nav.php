<nav class="navbar navbar-light navbar-expand-md fixed-top" id="dashboard-nav2">
    <div class="container-fluid"><a class="navbar-brand" href="index.php" id="dashboard-logo"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-2"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navcol-2">
            <ul class="nav navbar-nav">
                <li class="nav-item" role="presentation"><a class="nav-link nav-item-link" href="index.php">Dashboard</a></li>
                <li class="nav-item" role="presentation"><a class="nav-link nav-item-link" href="transfers.php">Transfers</a></li>
                <li class="nav-item" role="presentation"><a class="nav-link nav-item-link" href="fund-account.php">Fund Account</a></li>
                <li class="nav-item" role="presentation"><a class="nav-link nav-item-link" href="create-account.php">Accounts</a></li>
                <li class="nav-item" role="presentation"><a class="nav-link nav-item-link" href="logs.php">Logs</a></li>
                <li class="nav-item" role="presentation"><a class="nav-link nav-item-link" href="profile.php">Profile</a></li>
                <li class="nav-item" role="presentation"><a class="nav-link nav-item-link" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
<nav class="navbar navbar-light navbar-expand-md fixed-top" id="dashboard-nav">
    <div class="container-fluid"><a class="navbar-brand" href="index.php" id="dashboard-logo"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1" id="navbar-toggle1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon" style="background-image:initial;"><i class="icon-menu"></i></span></button>
        <div class="collapse navbar-collapse" id="navcol-1">
            <ul class="nav navbar-nav ml-auto">
                <li class="nav-item" role="presentation"><a class="nav-link dashboard-menu-btn" href="fund-account.php">Fund Account</a></li>
                <li class="dropdown"><a class="dropdown-toggle nav-link dropdown-toggle profile-dropdown" data-toggle="dropdown" aria-expanded="false" href="#">Admin&nbsp;<img class="rounded-circle img-fluid" src="../assets/img/favicon.png" width="30"></a>
                    <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="profile.php">Profile</a></div>
                </li>
                <li class="nav-item" role="presentation"><a class="nav-link" href="notifications.php"><i class="icon-speech notification-menu-icon"></i></a></li>
                <li class="nav-item" role="presentation"><a class="nav-link logout-menu-item" href="logout.php">Logout<i class="icon-power logout-menu-icon"></i></a></li>
            </ul>
        </div>
    </div>
</nav>
