<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.21/b-1.6.2/b-colvis-1.6.2/b-html5-1.6.2/b-print-1.6.2/cr-1.5.2/fc-3.3.1/fh-3.1.7/kt-2.5.2/r-2.2.5/sc-2.0.2/sp-1.1.1/datatables.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<!---
<script src="../assets/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../assets/datatables.net/Buttons-1.5.1/js/dataTables.buttons.min.js"></script>
<script src="../assets/datatables.net/js/dataTables.bootstrap4.min.js"></script>
<script src="../assets/datatables.net/Responsive-2.2.1/js/dataTables.responsive.min.js"></script>
<script src="../assets/datatables.net/Responsive-2.2.1/js/responsive.bootstrap4.min.js"></script>
<script src="../assets/datatables.net/JSZip-2.5.0/jszip.min.js"></script>
<script src="../assets/datatables.net/pdfmake-0.1.32/pdfmake.min.js"></script>
<script src="../assets/datatables.net/pdfmake-0.1.32/vfs_fonts.js"></script>
<script src="../assets/datatables.net/Buttons-1.5.1/js/buttons.bootstrap4.min.js"></script>
<script src="../assets/datatables.net/Buttons-1.5.1/js/buttons.html5.min.js"></script>
<script src="../assets/datatables.net/Buttons-1.5.1/js/buttons.print.min.js"></script>
<script src="../assets/datatables.net/Buttons-1.5.1/js/buttons.colVis.min.js"></script>
-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script src="../assets/js/zenable-tooltip.js"></script>
<script src="../assets/js/zscroll.js"></script>
<script src="../assets/js/zselect2.js"></script>
<script src="../assets/js/toastr.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable({
            "paging": true,
            "ordering": true,
            "info": false,
            "searching": true,
            "responsive": true,
            "language": {
                "decimal": ".",
                "thousands": ","
            },
            dom: 'Bfrtip',
            buttons: [
                'copy', 'excel', 'pdf', 'print'
            ]

        });
    });
    
    $(document).ready(function() {
        $('#example1').DataTable({
            "paging": true,
            "ordering": true,
            "info": false,
            "searching": true,
            "responsive": true,
            "language": {
                "decimal": ".",
                "thousands": ","
            },
            dom: 'Bfrtip',
            buttons: [
                'copy', 'excel', 'pdf', 'print'
            ]

        });
    });
</script>
