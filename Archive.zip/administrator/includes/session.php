<?php
if(isset($_SESSION['session_id']))
    {
        $current_user = new arkuser($_SESSION['session_id']);
        if($current_user->acctype !== "1")
            {
                echo"<meta http-equiv='refresh' content='0;url=logout.php'>";
            }
    }
else
    {
        header('location: logout.php');
    }
?>