<?php
$config = parse_ini_file("../../../config.ini");
include'../../includes/connect.php';
include'../../classes/users.php';
include'session.php';
$logdatetime = time();
function generateRandomStringLog($length = 15) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
$arklog_id = generateRandomStringLog();

if(isset($_POST['confirm_new_password']))
{
    $password = addslashes(strip_tags($_POST['password']));
    $new_password = addslashes(strip_tags($_POST['new_password']));
    $confirm_new_password = addslashes(strip_tags($_POST['confirm_new_password']));
    if($password == $current_user->password)
		{
			if($new_password == $confirm_new_password)
				{
					$query = $connect->query("UPDATE arkuserinfo SET password = '$new_password' WHERE arkuserinfo_id = '$current_user->arkuserinfo_id'");
                    $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Password Changed by Administrator','$logdatetime')");
					$response['status'] = "success";
					echo json_encode($response);
				}
			else
				{
					echo json_encode("Passwords entered don't match");
				}
		}
	else
		{
			echo json_encode("Wrong password entered");
		}
}


if(isset($_POST['edited_first_name']))
{
    $first_name = addslashes(strip_tags($_POST['edited_first_name']));
    $last_name = addslashes(strip_tags($_POST['edited_last_name']));
    $gender = addslashes(strip_tags($_POST['edited_gender']));
    $email = addslashes(strip_tags($_POST['edited_email']));
    $contact = addslashes(strip_tags($_POST['edited_contact']));
    $account_type = addslashes(strip_tags($_POST['edited_account_type']));
    $password = addslashes(strip_tags($_POST['edited_password']));
    $retype_password = addslashes(strip_tags($_POST['edited_retype_password']));
    $arkuserid = addslashes(strip_tags($_POST['arkuserid']));
    $datetime = time();
    $query = $connect->query("SELECT * FROM arkuserinfo WHERE arkuserinfo_id='$arkuserid'");
    if($query->rowCount() >= 1)
		{
            if($password == $retype_password)
                {
                    $query = $connect->query("UPDATE arkuserinfo SET first_name = '$first_name', last_name = '$last_name', gender = '$gender', contact = '$contact', password = '$password' WHERE arkuserinfo_id = '$arkuserid'");   
                    $response['status'] = "success";
					echo json_encode($response);
                }
            else
                {
                    echo json_encode("Passwords entered don't match");
                }
        }
    else
        {
            echo json_encode("Invalid user selection");
        }
}

if(isset($_POST['first_name']))
{
    function generateRandomString($length = 21) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
    $arkuserinfo_id = generateRandomString();
    $customer_number = rand(12346789,987654321);
    $first_name = addslashes(strip_tags($_POST['first_name']));
    $last_name = addslashes(strip_tags($_POST['last_name']));
    $gender = addslashes(strip_tags($_POST['gender']));
    $email = addslashes(strip_tags($_POST['email']));
    $contact = addslashes(strip_tags($_POST['contact']));
    $account_type = addslashes(strip_tags($_POST['account_type']));
    $password = addslashes(strip_tags($_POST['password']));
    $datetime = time();
    $bank_account_type = addslashes(strip_tags($_POST['bank_account_type']));
    $customer_account_number = addslashes(strip_tags($_POST['customer_account_number']));
   
    $query = $connect->query("SELECT * FROM arkuserinfo WHERE email='$email' OR contact = '$contact'");
    if($query->rowCount() >= 1)
		{
            echo json_encode("User with email or contact entered already exists");
        }
    else
        {
            $query = $connect->query("INSERT INTO arkuserinfo VALUES('$arkuserinfo_id','$customer_number','$first_name','$last_name','$email','$password','$gender','','$contact','','','','','$datetime','2','1','1')");
            if($account_type == '2')
                {
                    $query1 = $connect->query("INSERT INTO arkaccountinfo VALUES('$arkuserinfo_id','$customer_number','$customer_account_number','0','$bank_account_type')");
                    $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','User Account Created by Administrator','$logdatetime')");
                    //send html message
                    $to = $email;
                    $from = "customercare@acetrust.online";

                    // To send HTML mail, the Content-type header must be set
                    $headers  = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";

                    // Create email headers
                    $headers .= 'From: '.$from."\r\n".
                    'Reply-To: '.$from."\r\n" .
                    'X-Mailer: PHP/' . phpversion();
                    
                    $subject = "Account Created";
                
                    $email_message = '
                        <!DOCTYPE html>
                            <html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
                            <head>
                                <title></title>
                                <!--[if !mso]><!-- -->
                                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                                <!--<![endif]-->
                                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
                                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                                <style type="text/css">
                                    #outlook a {
                                        padding: 0;
                                    }
                                    .ReadMsgBody {
                                        width: 100%;
                                    }
                                    .ExternalClass {
                                        width: 100%;
                                    }
                                    .ExternalClass * {
                                        line-height: 100%;
                                    }
                                    body {
                                        margin: 0;
                                        padding: 0;
                                        -webkit-text-size-adjust: 100%;
                                        -ms-text-size-adjust: 100%;
                                    }
                                    table,
                                    td {
                                        border-collapse: collapse;
                                        mso-table-lspace: 0pt;
                                        mso-table-rspace: 0pt;
                                    }
                                    img {
                                        border: 0;
                                        height: auto;
                                        line-height: 100%;
                                        outline: none;
                                        text-decoration: none;
                                        -ms-interpolation-mode: bicubic;
                                    }
                                    p {
                                        display: block;
                                        margin: 13px 0;
                                    }
                                </style>
                                <!--[if !mso]><!-->
                                <style type="text/css">
                                    @media only screen and (max-width:480px) {
                                        @-ms-viewport {
                                            width: 320px;
                                        }
                                        @viewport {
                                            width: 320px;
                                        }
                                    }
                                </style>
                                <!--<![endif]-->
                                <!--[if mso]><xml>  <o:OfficeDocumentSettings>    <o:AllowPNG/>    <o:PixelsPerInch>96</o:PixelsPerInch>  </o:OfficeDocumentSettings></xml><![endif]-->
                                <!--[if lte mso 11]><style type="text/css">  .outlook-group-fix {    width:100% !important;  }</style><![endif]-->
                                <!--[if !mso]><!-->
                                <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet" type="text/css">
                                <style type="text/css">
                                    @import url(https://fonts.googleapis.com/css?family=Ubuntu);
                                </style>
                                <!--<![endif]-->
                                <style type="text/css">
                                    @media only screen and (min-width:480px) {
                                        .mj-column-per-100 {
                                            width: 100% !important;
                                        }
                                    }
                                </style>
                            </head>
                            <body style="background: #FFFFFF;">
                                <div class="mj-container" style="background-color:#FFFFFF;">
                                    <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="width:600px;">        <tr>          <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;">      <![endif]-->
                                    <div style="margin:0px auto;max-width:600px;background:url(https://eesglobaltrust.com/web/images/1541624435.jpg) top center / auto repeat;">
                                        <!--[if mso | IE]>      <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:600px;">        <v:fill origin="0.5, 0" position="0.5,0" type="tile" src="https://topolio.s3.eu-west-1.amazonaws.com/uploads/5be35100990f8/1541624435.jpg" />        <v:textbox style="mso-fit-shape-to-text:true" inset="0,0,0,0">      <![endif]-->
                                        <table role="presentation" cellpadding="0" cellspacing="0" style="font-size:0px;width:100%;background:url(https://topolio.s3.eu-west-1.amazonaws.com/uploads/5be35100990f8/1541624435.jpg) top center / auto repeat;" align="center" border="0" background="https://topolio.s3.eu-west-1.amazonaws.com/uploads/5be35100990f8/1541624435.jpg">
                                            <tbody>
                                                <tr>
                                                    <td style="text-align:center;vertical-align:top;direction:ltr;font-size:0px;padding:9px 0px 9px 0px;">
                                                        <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0">        <tr>          <td style="vertical-align:top;width:600px;">      <![endif]-->
                                                        <div class="mj-column-per-100 outlook-group-fix" style="vertical-align:top;display:inline-block;direction:ltr;font-size:13px;text-align:left;width:100%;">
                                                            <table role="presentation" cellpadding="0" cellspacing="0" style="vertical-align:top;" width="100%" border="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="word-wrap:break-word;font-size:0px;padding:20px 20px 20px 20px;" align="center">
                                                                            <table role="presentation" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-spacing:0px;" align="center" border="0">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="width:234px;"><img alt="" title="" height="auto" src="https://eesglobaltrust.com/web/images/1541624444.jpg" style="border:none;border-radius:0px;display:block;font-size:13px;outline:none;text-decoration:none;width:100%;height:auto;" width="234"></td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                        <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!--[if mso | IE]>        </v:textbox>      </v:rect>      <![endif]-->
                                    </div>
                                    <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                    <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="width:600px;">        <tr>          <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;">      <![endif]-->
                                    <div style="margin:0px auto;max-width:600px;">
                                        <table role="presentation" cellpadding="0" cellspacing="0" style="font-size:0px;width:100%;" align="center" border="0">
                                            <tbody>
                                                <tr>
                                                    <td style="text-align:center;vertical-align:top;direction:ltr;font-size:0px;padding:9px 0px 9px 0px;">
                                                        <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0">        <tr>          <td style="vertical-align:top;width:600px;">      <![endif]-->
                                                        <div class="mj-column-per-100 outlook-group-fix" style="vertical-align:top;display:inline-block;direction:ltr;font-size:13px;text-align:left;width:100%;">
                                                            <table role="presentation" cellpadding="0" cellspacing="0" style="vertical-align:top;" width="100%" border="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="word-wrap:break-word;font-size:0px;padding:15px 15px 15px 15px;" align="left">
                                                                            <div style="cursor:auto;color:#000000;font-family:Ubuntu, sans-serif;font-size:11px;line-height:1.5;text-align:left;">
                                                                                <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                                                                    <tbody>
                                                                                                        <tr>
                                                                                                            <td align="left">
                                                                                                                <p>Dear Customer,</p>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                            <td align="left">
                                                                                                                <p>Your account has been successfully created and activated. Please find below your login information.</p>
                                                                                                                <p>Customer Number: '.$customer_number.'<br/>Password: '.$password.'</p>
                                                                                                                <p>Thank you for banking with Us.</p>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                            <td align="left">
                                                                                                                <p>For more information please visit our website at www.eesglobaltrust.com, chat with our live agent via our website or call us on: +1 800 000 0000</p>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                        <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                    <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="width:600px;">        <tr>          <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;">      <![endif]-->
                                    <div style="margin:0px auto;max-width:600px;background:#F6F6F6;">
                                        <table role="presentation" cellpadding="0" cellspacing="0" style="font-size:0px;width:100%;background:#F6F6F6;" align="center" border="0">
                                            <tbody>
                                                <tr>
                                                    <td style="text-align:center;vertical-align:top;direction:ltr;font-size:0px;padding:9px 0px 9px 0px;">
                                                        <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0">        <tr>          <td style="vertical-align:top;width:600px;">      <![endif]-->
                                                        <div class="mj-column-per-100 outlook-group-fix" style="vertical-align:top;display:inline-block;direction:ltr;font-size:13px;text-align:left;width:100%;">
                                                            <table role="presentation" cellpadding="0" cellspacing="0" style="vertical-align:top;" width="100%" border="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="word-wrap:break-word;font-size:0px;padding:15px 15px 15px 15px;" align="left">
                                                                            <div style="cursor:auto;color:#000000;font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:11px;line-height:1.5;text-align:left;">
                                                                                <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                                                                    <tbody>
                                                                                                        <tr>
                                                                                                            <td align="center">
                                                                                                                <p>If this mail was wrongly addressed to you please delete it immediately. We apologize for the incovience. If you continue to receive an E-Mail from us please contact our support team at&#xA0;<a href="mailto:customercare@acetrust.online?subject=Help%3A%20SPAM%20MAIL&amp;body=Please%20remove%20my%20email%20from%20your%20mailing%20list.%20This%20mail%20was%20not%20meant%20for%20me.%20Thank%20you.">customercare@acetrust.online</a></p>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="word-wrap:break-word;font-size:0px;padding:10px 10px 10px 10px;" align="center">
                                                                            <div>
                                                                                <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0" align="undefined"><tr><td>      <![endif]-->
                                                                                <table role="presentation" cellpadding="0" cellspacing="0" style="float:none;display:inline-table;" align="center" border="0">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td style="padding:4px;vertical-align:middle;">
                                                                                                <table role="presentation" cellpadding="0" cellspacing="0" style="background:none;border-radius:3px;width:35px;" border="0">
                                                                                                    <tbody>
                                                                                                        <tr>
                                                                                                            <td style="vertical-align:middle;width:35px;height:35px;"><a href="https://www.facebook.com/"><img alt="facebook" height="35" src="https://eesglobaltrust.com/web/images/facebook.png" style="display:block;border-radius:3px;" width="35"></a></td>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                                <!--[if mso | IE]>      </td><td>      <![endif]-->
                                                                                <table role="presentation" cellpadding="0" cellspacing="0" style="float:none;display:inline-table;" align="center" border="0">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td style="padding:4px;vertical-align:middle;">
                                                                                                <table role="presentation" cellpadding="0" cellspacing="0" style="background:none;border-radius:3px;width:35px;" border="0">
                                                                                                    <tbody>
                                                                                                        <tr>
                                                                                                            <td style="vertical-align:middle;width:35px;height:35px;"><a href="https://www.twitter.com/"><img alt="twitter" height="35" src="https://eesglobaltrust.com/web/images/twitter.png" style="display:block;border-radius:3px;" width="35"></a></td>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                                <!--[if mso | IE]>      </td><td>      <![endif]-->
                                                                                <table role="presentation" cellpadding="0" cellspacing="0" style="float:none;display:inline-table;" align="center" border="0">
                                                                                    <tbody>
                                                                                        <tr>
                                                                                            <td style="padding:4px;vertical-align:middle;">
                                                                                                <table role="presentation" cellpadding="0" cellspacing="0" style="background:none;border-radius:3px;width:35px;" border="0">
                                                                                                    <tbody>
                                                                                                        <tr>
                                                                                                            <td style="vertical-align:middle;width:35px;height:35px;"><a href="https://plus.google.com/"><img alt="google" height="35" src="https://eesglobaltrust.com/web/images/google-plus.png" style="display:block;border-radius:3px;" width="35"></a></td>
                                                                                                        </tr>
                                                                                                    </tbody>
                                                                                                </table>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                                <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                        <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                </div>
                            </body>
                            </html>
                        ';
                    mail($to, $subject, $email_message, $headers);
                    $response['status'] = "success";
					echo json_encode($response);
                }
            else
                {
                    $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Administrator Account Created by Administrator','$logdatetime')");
                    $response['status'] = "success";
					echo json_encode($response);
                }
        }
}

if(isset($_POST['subject']))
{
    function generateRandomString($length = 15) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
    $arkhtmlmail_id = generateRandomString();
    $subject = addslashes(strip_tags($_POST['subject']));
    $recipient = addslashes(strip_tags($_POST['recipient']));
    $html_message = addslashes(strip_tags($_POST['html_message']));
    $datetime = time();
    //send html mail
    
    $to = $recipient;
    $from = "noreply@eesglobaltrust.com";
                        	
    // To send HTML mail, the Content-type header must be set
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                        		
    // Create email headers
    $headers .= 'From: '.$from."\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();
    
    $email_message = '
    <!DOCTYPE html>
        <html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
        <head>
            <title></title>
            <!--[if !mso]><!-- -->
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <!--<![endif]-->
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style type="text/css">
                #outlook a {
                    padding: 0;
                }
                .ReadMsgBody {
                    width: 100%;
                }
                .ExternalClass {
                    width: 100%;
                }
                .ExternalClass * {
                    line-height: 100%;
                }
                body {
                    margin: 0;
                    padding: 0;
                    -webkit-text-size-adjust: 100%;
                    -ms-text-size-adjust: 100%;
                }
                table,
                td {
                    border-collapse: collapse;
                    mso-table-lspace: 0pt;
                    mso-table-rspace: 0pt;
                }
                img {
                    border: 0;
                    height: auto;
                    line-height: 100%;
                    outline: none;
                    text-decoration: none;
                    -ms-interpolation-mode: bicubic;
                }
                p {
                    display: block;
                    margin: 13px 0;
                }
            </style>
            <!--[if !mso]><!-->
            <style type="text/css">
                @media only screen and (max-width:480px) {
                    @-ms-viewport {
                        width: 320px;
                    }
                    @viewport {
                        width: 320px;
                    }
                }
            </style>
            <!--<![endif]-->
            <!--[if mso]><xml>  <o:OfficeDocumentSettings>    <o:AllowPNG/>    <o:PixelsPerInch>96</o:PixelsPerInch>  </o:OfficeDocumentSettings></xml><![endif]-->
            <!--[if lte mso 11]><style type="text/css">  .outlook-group-fix {    width:100% !important;  }</style><![endif]-->
            <!--[if !mso]><!-->
            <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet" type="text/css">
            <style type="text/css">
                @import url(https://fonts.googleapis.com/css?family=Ubuntu);
            </style>
            <!--<![endif]-->
            <style type="text/css">
                @media only screen and (min-width:480px) {
                    .mj-column-per-100 {
                        width: 100% !important;
                    }
                }
            </style>
        </head>
        <body style="background: #FFFFFF;">
            <div class="mj-container" style="background-color:#FFFFFF;">
                <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="width:600px;">        <tr>          <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;">      <![endif]-->
                <div style="margin:0px auto;max-width:600px;background:url(https://eesglobaltrust.com/web/images/1541624435.jpg) top center / auto repeat;">
                    <!--[if mso | IE]>      <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:600px;">        <v:fill origin="0.5, 0" position="0.5,0" type="tile" src="https://topolio.s3.eu-west-1.amazonaws.com/uploads/5be35100990f8/1541624435.jpg" />        <v:textbox style="mso-fit-shape-to-text:true" inset="0,0,0,0">      <![endif]-->
                    <table role="presentation" cellpadding="0" cellspacing="0" style="font-size:0px;width:100%;background:url(https://topolio.s3.eu-west-1.amazonaws.com/uploads/5be35100990f8/1541624435.jpg) top center / auto repeat;" align="center" border="0" background="https://topolio.s3.eu-west-1.amazonaws.com/uploads/5be35100990f8/1541624435.jpg">
                        <tbody>
                            <tr>
                                <td style="text-align:center;vertical-align:top;direction:ltr;font-size:0px;padding:9px 0px 9px 0px;">
                                    <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0">        <tr>          <td style="vertical-align:top;width:600px;">      <![endif]-->
                                    <div class="mj-column-per-100 outlook-group-fix" style="vertical-align:top;display:inline-block;direction:ltr;font-size:13px;text-align:left;width:100%;">
                                        <table role="presentation" cellpadding="0" cellspacing="0" style="vertical-align:top;" width="100%" border="0">
                                            <tbody>
                                                <tr>
                                                    <td style="word-wrap:break-word;font-size:0px;padding:20px 20px 20px 20px;" align="center">
                                                        <table role="presentation" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-spacing:0px;" align="center" border="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="width:234px;"><img alt="" title="" height="auto" src="https://eesglobaltrust.com/web/images/1541624444.jpg" style="border:none;border-radius:0px;display:block;font-size:13px;outline:none;text-decoration:none;width:100%;height:auto;" width="234"></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <!--[if mso | IE]>        </v:textbox>      </v:rect>      <![endif]-->
                </div>
                <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="width:600px;">        <tr>          <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;">      <![endif]-->
                <div style="margin:0px auto;max-width:600px;">
                    <table role="presentation" cellpadding="0" cellspacing="0" style="font-size:0px;width:100%;" align="center" border="0">
                        <tbody>
                            <tr>
                                <td style="text-align:center;vertical-align:top;direction:ltr;font-size:0px;padding:9px 0px 9px 0px;">
                                    <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0">        <tr>          <td style="vertical-align:top;width:600px;">      <![endif]-->
                                    <div class="mj-column-per-100 outlook-group-fix" style="vertical-align:top;display:inline-block;direction:ltr;font-size:13px;text-align:left;width:100%;">
                                        <table role="presentation" cellpadding="0" cellspacing="0" style="vertical-align:top;" width="100%" border="0">
                                            <tbody>
                                                <tr>
                                                    <td style="word-wrap:break-word;font-size:0px;padding:15px 15px 15px 15px;" align="left">
                                                        <div style="cursor:auto;color:#000000;font-family:Ubuntu, sans-serif;font-size:11px;line-height:1.5;text-align:left;">
                                                            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation">
                                                                <tbody>
                                                                    <tr>
                                                                        <td>
                                                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td align="left">
                                                                                            <p>Dear Customer,</p>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td align="left">
                                                                                            <p>'.$html_message.'</p>
                                                                                        </td>
                                                                                    </tr>
                                                                                    <tr>
                                                                                        <td align="left">
                                                                                            <p>For more information please visit our website at www.eesglobaltrust.com, chat with our live agent via our website or call us on: +1 800 000 0000</p>
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="width:600px;">        <tr>          <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;">      <![endif]-->
                <div style="margin:0px auto;max-width:600px;background:#F6F6F6;">
                    <table role="presentation" cellpadding="0" cellspacing="0" style="font-size:0px;width:100%;background:#F6F6F6;" align="center" border="0">
                        <tbody>
                            <tr>
                                <td style="text-align:center;vertical-align:top;direction:ltr;font-size:0px;padding:9px 0px 9px 0px;">
                                    <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0">        <tr>          <td style="vertical-align:top;width:600px;">      <![endif]-->
                                    <div class="mj-column-per-100 outlook-group-fix" style="vertical-align:top;display:inline-block;direction:ltr;font-size:13px;text-align:left;width:100%;">
                                        <table role="presentation" cellpadding="0" cellspacing="0" style="vertical-align:top;" width="100%" border="0">
                                            <tbody>
                                                <tr>
                                                    <td style="word-wrap:break-word;font-size:0px;padding:15px 15px 15px 15px;" align="left">
                                                        <div style="cursor:auto;color:#000000;font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:11px;line-height:1.5;text-align:left;">
                                                            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation">
                                                                <tbody>
                                                                    <tr>
                                                                        <td>
                                                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td align="center">
                                                                                            <p>If this mail was wrongly addressed to you please delete it immediately. We apologize for the incovience. If you continue to receive an E-Mail from us please contact our support team at&#xA0;<a href="mailto:customercare@acetrust.online?subject=Help%3A%20SPAM%20MAIL&amp;body=Please%20remove%20my%20email%20from%20your%20mailing%20list.%20This%20mail%20was%20not%20meant%20for%20me.%20Thank%20you.">customercare@acetrust.online</a></p>
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="word-wrap:break-word;font-size:0px;padding:10px 10px 10px 10px;" align="center">
                                                        <div>
                                                            <!--[if mso | IE]>      <table role="presentation" border="0" cellpadding="0" cellspacing="0" align="undefined"><tr><td>      <![endif]-->
                                                            <table role="presentation" cellpadding="0" cellspacing="0" style="float:none;display:inline-table;" align="center" border="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="padding:4px;vertical-align:middle;">
                                                                            <table role="presentation" cellpadding="0" cellspacing="0" style="background:none;border-radius:3px;width:35px;" border="0">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="vertical-align:middle;width:35px;height:35px;"><a href="https://www.facebook.com/"><img alt="facebook" height="35" src="https://eesglobaltrust.com/web/images/facebook.png" style="display:block;border-radius:3px;" width="35"></a></td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <!--[if mso | IE]>      </td><td>      <![endif]-->
                                                            <table role="presentation" cellpadding="0" cellspacing="0" style="float:none;display:inline-table;" align="center" border="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="padding:4px;vertical-align:middle;">
                                                                            <table role="presentation" cellpadding="0" cellspacing="0" style="background:none;border-radius:3px;width:35px;" border="0">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="vertical-align:middle;width:35px;height:35px;"><a href="https://www.twitter.com/"><img alt="twitter" height="35" src="https://eesglobaltrust.com/web/images/twitter.png" style="display:block;border-radius:3px;" width="35"></a></td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <!--[if mso | IE]>      </td><td>      <![endif]-->
                                                            <table role="presentation" cellpadding="0" cellspacing="0" style="float:none;display:inline-table;" align="center" border="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="padding:4px;vertical-align:middle;">
                                                                            <table role="presentation" cellpadding="0" cellspacing="0" style="background:none;border-radius:3px;width:35px;" border="0">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td style="vertical-align:middle;width:35px;height:35px;"><a href="https://plus.google.com/"><img alt="google" height="35" src="https://eesglobaltrust.com/web/images/google-plus.png" style="display:block;border-radius:3px;" width="35"></a></td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <!--[if mso | IE]>      </td></tr></table>      <![endif]-->
            </div>
        </body>
        </html>
    ';
    $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','HTML Mail Sent by Administrator','$logdatetime')");
    $query = $connect->query("INSERT INTO arkhtmlmail VALUES('$arkhtmlmail_id','$subject','$recipient','$html_message','$datetime')");
    mail($to, $subject, $email_message, $headers);
    $response['status'] = "success";
    echo json_encode($response);
}

if(isset($_POST['title']))
{
    function generateRandomString($length = 15) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
    $arknotification_id = generateRandomString();
    $title = addslashes(strip_tags($_POST['title']));
    $recipient = addslashes(strip_tags($_POST['recipient']));
    $message = addslashes(strip_tags($_POST['message']));
    $datetime = time();
    $query = $connect->query("SELECT * FROM arkuserinfo WHERE email='$recipient' OR customer_number='$recipient'");
    if($query->rowCount() >= 1)
		{
            foreach($query as $row)
				{
					$db_id = $row['arkuserinfo_id'];
                }
            $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Notification Sent by Administrator','$logdatetime')");
            $query = $connect->query("INSERT INTO arknotification VALUES('$arknotification_id','$title','$recipient','$message','$datetime')");
            $response['status'] = "success";
            echo json_encode($response);
        }
    else
        {
            echo json_encode("Invalid recipient information");
        }
}

if(isset($_POST['date_of_birth']))
{
    $date_of_birth = addslashes(strip_tags($_POST['date_of_birth']));
    $first_name = addslashes(strip_tags($_POST['first_name_profile']));
    $last_name = addslashes(strip_tags($_POST['last_name_profile']));
    $gender = addslashes(strip_tags($_POST['gender']));
    $email = addslashes(strip_tags($_POST['email']));
    $contact = addslashes(strip_tags($_POST['contact']));
    $address = addslashes(strip_tags($_POST['address']));
    $city = addslashes(strip_tags($_POST['city']));
    $state = addslashes(strip_tags($_POST['state']));
    $country = addslashes(strip_tags($_POST['country']));
    $query = $connect->query("UPDATE arkuserinfo SET first_name = '$first_name', last_name = '$last_name', gender = '$gender', dob = '$date_of_birth', contact = '$contact', address = '$address', city = '$city', state = '$state', country = '$country' WHERE arkuserinfo_id = '$current_user->arkuserinfo_id'");
    $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Profile Updated by Administrator','$logdatetime')");
    $response['status'] = "success";
    echo json_encode($response);
}
//Fund Account
if(isset($_POST['transaction_details']))
{
    function generateRandomString($length = 15) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
    $arktransaction_id = generateRandomString();
    $account_number = addslashes(strip_tags($_POST['account_number']));
    $amount = addslashes(strip_tags($_POST['amount']));
    $transaction_details = addslashes(strip_tags($_POST['transaction_details']));
    $datetime = addslashes(strip_tags($_POST['epochtime']));
    $query = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number='$account_number' OR account_number='$account_number'");
    if($query->rowCount() >= 1)
		{
            foreach($query as $row)
				{
					$balance = $row['balance'];
					$customer_number = $row['customer_number'];
                }
            $newbalance = $balance + $amount;
            $query = $connect->query("UPDATE arkaccountinfo SET balance = '$newbalance' WHERE customer_number='$account_number' OR account_number='$account_number'");
            $query = $connect->query("INSERT INTO arktransactions VALUES('$arktransaction_id','$customer_number','$transaction_details','$amount','0','$datetime','1')");
            $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Account Credited (Deposit) by Administrator','$logdatetime')");
            $response['status'] = "success";
            echo json_encode($response);
        }
    else
        {
            echo json_encode("Invalid account information");
        }
}
?>