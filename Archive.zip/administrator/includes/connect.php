<?php
session_start();
date_default_timezone_set('Africa/Lagos');

define("DB_USERNAME", $config['username']);
define("DB_NAME", $config['dbname']);
define("DB_PASSWORD", $config['password']);

$retries = 3;
while ($retries > 0)
{
    try
    {
       $db_name = $config['dbname'];
       $connect = new PDO("mysql:host=localhost;dbname=".DB_NAME.";",DB_USERNAME,DB_PASSWORD);
       // Do query, etc.
       $retries = 0;
    }
    catch (PDOException $e)
    {
        // Should probably check $e is a connection error, could be a query error!
        echo"
		<div class='bg-red padding_5 font-white' style='z-index: 99999;font-family:sans-serif;position: fixed;width:100%;top:0;'>
			System down. Please refresh or try again later
		</div>
		";
        $retries--;
        usleep(500); // Wait 0.5s between retries.
        echo $e->getMessage();
        exit;
    }
}
?>