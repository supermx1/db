<div id="navmenu"></div>
<ul class="list-group">
    <li class="list-group-item text-center list-group-item1"><a href="index.php" class="link7"><i class="la la-dashboard navmenu-icon"></i>
            <p class="text-center navmenu-p">Dashboard</p>
        </a>
    </li>
    <li class="list-group-item text-center list-group-item1"><a href="transfers.php" class="link7"><i class="la la-exchange navmenu-icon"></i>
            <p class="text-center navmenu-p">Transfers</p>
        </a>
    </li>
    <li class="list-group-item text-center list-group-item1"><a href="fund-account.php" class="link7"><i class="la la-dollar navmenu-icon"></i>
            <p class="text-center navmenu-p">Fund Account</p>
        </a>
    </li>
    <li class="list-group-item text-center list-group-item1"><a href="create-account.php" class="link7"><i class="la la-user-plus navmenu-icon"></i>
            <p class="text-center navmenu-p">Accounts</p>
        </a>
    </li>
    <li class="list-group-item text-center list-group-item1"><a href="logs.php" class="link7"><i class="la la-area-chart navmenu-icon"></i>
            <p class="text-center navmenu-p">Logs</p>
        </a>
    </li>
    <li class="list-group-item text-center list-group-item1"><a href="profile.php" class="link7"><i class="la la-user navmenu-icon"></i>
            <p class="text-center navmenu-p">Profile</p>
        </a>
    </li>
</ul>
