<script>
    $("#changepassword_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("old_password");
        inputs[1] = document.getElementById("new_password");
        inputs[2] = document.getElementById("confirm_password");
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Password successfully changed');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#create_account_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("first_name");
        inputs[1] = document.getElementById("last_name");
        inputs[2] = document.getElementById("email");
        inputs[3] = document.getElementById("contact");
        inputs[4] = document.getElementById("acctype");
        inputs[5] = document.getElementById("password");
        inputs[6] = document.getElementById("retypepassword");
        inputs[7] = document.getElementById("bankacctype");
        inputs[8] = document.getElementById("account_number");
        
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        var validate_email = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var email = document.getElementById("email");

        if(email.value !== '')
			{
				if(validate_email.test(email.value) === true)
					{
						
					}
				else
					{
						email.style.background = "#ffcccc";
						toastr.error(email.name + ' is not a valid email address');
						res = false;
					}
			}
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Account successfully created');
							setTimeout(function(){
							window.location.href= 'create-account.php';},2000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#send_htmlmail").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("subject");
        inputs[1] = document.getElementById("htmlrecipient");
        inputs[2] = document.getElementById("htmlmessage");
        
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        var validate_email = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var email = document.getElementById("recipient");

        if(email.value !== '')
			{
				if(validate_email.test(email.value) === true)
					{
						
					}
				else
					{
						email.style.background = "#ffcccc";
						toastr.error(email.name + ' is not a valid email address');
						res = false;
					}
			}
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('HTML message successfully sent');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#create_notification").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("title");
        inputs[1] = document.getElementById("recipient");
        inputs[2] = document.getElementById("message");
        
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        var validate_email = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var email = document.getElementById("recipient");

        if(email.value !== '')
			{
				if(validate_email.test(email.value) === true)
					{
						
					}
				else
					{
						email.style.background = "#ffcccc";
						toastr.error(email.name + ' is not a valid email address');
						res = false;
					}
			}
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Notification successfully sent');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#edit_profile_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("firstname");
        inputs[1] = document.getElementById("lastname");
        inputs[2] = document.getElementById("gender");
        inputs[3] = document.getElementById("dob");
        inputs[4] = document.getElementById("email");
        inputs[5] = document.getElementById("contact");
        inputs[6] = document.getElementById("address");
        inputs[7] = document.getElementById("city");
        inputs[8] = document.getElementById("state");
        inputs[9] = document.getElementById("country");
        
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        var validate_email = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var email = document.getElementById("email");

        if(email.value !== '')
			{
				if(validate_email.test(email.value) === true)
					{
						
					}
				else
					{
						email.style.background = "#ffcccc";
						toastr.error(email.name + ' is not a valid email address');
						res = false;
					}
			}
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Profile successfully edited');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>


<script>
    $("#fund_account").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("accountnumber");
        inputs[1] = document.getElementById("amount");
        inputs[2] = document.getElementById("epochtime");
        inputs[3] = document.getElementById("transactiondetails");
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Account successfully funded');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#edit_account_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("first_name");
        inputs[1] = document.getElementById("last_name");
        inputs[2] = document.getElementById("email");
        inputs[3] = document.getElementById("contact");
        inputs[4] = document.getElementById("password");
        inputs[5] = document.getElementById("retypepassword");
        
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        var validate_email = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var email = document.getElementById("email");

        if(email.value !== '')
			{
				if(validate_email.test(email.value) === true)
					{
						
					}
				else
					{
						email.style.background = "#ffcccc";
						toastr.error(email.name + ' is not a valid email address');
						res = false;
					}
			}
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Account successfully edited');
							setTimeout(function(){
							window.location.href= 'create-account.php';},2000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>