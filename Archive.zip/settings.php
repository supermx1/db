<?php
$symbol = "€";
$currency = "Euro";
$cardnumber = "5138 2846 1093 5109";
$bankurl = "oneswissbank.com";
$bankname = "One Swiss Bank";
$logosize = " #dashboard-logo {
  width: 300px !important;
}";
$dashlogo = "#dashboard-logo {
  background-image: url('http://45.61.138.3/app/logo-top.png');
  background-position: center;
  background-size: 13%;
  background-repeat: no-repeat;
  height: 50px;
  width: 100px;
}";
$logo = "<img src='http://45.61.138.3/app/logo-bottom.png' height='70px'/>";
$altlogo = "<img src='http://45.61.138.3/app/logo-bottom.png' height='70px'/>";
$chat ="#"
?>