<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'../classes/profile.php';
include'includes/session.php';
include'includes/header.php';
include'../settings.php';


$query1 = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$current_user->customer_number'");
foreach($query1 as $row1)
    {
        $cu_balance = $row1['balance'];
    }
$display_cu_balance = number_format($cu_balance);
?>
<body class="body">

    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">

            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col"><button class="btn btn-primary pull-right btn1" type="button"><i class="la la-support btn-icon"></i>Contact Support</button>
                    <h4 class="main-col-row1-heading">Transfers</h4>
                    <p class="main-col-row1-p">You are on the transfers page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-8">
                    <div class="card card2">
                        <div class="card-body">
                            <div>
                                <ul class="nav nav-pills">
                                    <li class="nav-item mr-2"><a class="nav-link active link2" role="tab" data-toggle="pill" href="#tab-4"><?php echo $bankname ?> Acount</a></li>
                                    <li class="nav-item"><a class="nav-link link2" role="tab" data-toggle="pill" href="#tab-5">External Banks</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" role="tabpanel" id="tab-4">
                                        <form id="internal_transfer_form">
                                            <div class="trans-form">
                                                
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>Account Number</label>
                                                            <input class="form-control text-box" type="text" id="accountnumber" name="account number" placeholder="Account Number"></div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>Account Type</label>
                                                            <select class="form-control text-box" id="account" name="account">
                                                                <optgroup label="Account Type">
                                                                    <option value="" selected="">- Select Account Type -</option>
                                                                    <?php echo "<option value='$currency'>$currency($symbol)</option>"?>
                                                                </optgroup>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>Amount</label><input class="form-control text-box" type="number" id="amount" name="amount" placeholder="Amount to Transfer"></div>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label>Details</label><textarea class="form-control text-box" rows="3" id="transactiondetails" name="transaction details" placeholder="Transaction Details"></textarea></div>
                                                    </div>
                                                </div>
                                                <div class="form-row text-center spacer">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <div class="form-check"><input class="form-check-input" type="checkbox" id="terms" name="terms"><label class="form-check-label agree-box" for="formCheck-1">Agree to our Terms &amp; Conditions</label></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-row text-center spacer">
                                                    <div class="col">
                                                        <div class="form-group"><button class="btn btn-primary btn3" type="submit">Make Transfer</button></div>
                                                    </div>
                                                </div>
                                            </div>
                                            </form>
                                    </div>
                                    <div class="tab-pane fade" role="tabpanel" id="tab-5">
                                        <form id="extfundstransfer_form">
                                            <div class="trans-form">
                                                <?php echo "Account Balance: $symbol$display_cu_balance" ?>
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" id="bankname" name="bank name" placeholder="Bank Name"></div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" id="extaccountnumber" name="external account number" placeholder="Account Number"></div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" id="confirmaccountnumber" name="confirm account number" placeholder="Confirm Account Number"></div>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" id="beneficiaryname" name="beneficiary name" placeholder="Beneficiary Name"></div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" id="swiftbic" name="swift bic" placeholder="SWIFT/BIC"></div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" id="abartn" name="aba rtn" placeholder="ABA/RTN"></div>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <select class="form-control text-box" id="accounttype" name="account type">
                                                                <optgroup label="Account Type">
                                                                    <option value="" selected="">- Select Account Type -</option>
                                                                    <?php echo "<option value='$currency'>$currency($symbol)</option>"?>
                                                                </optgroup>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="number" id="extamount" name="transfer amount" placeholder="Amount to Transfer"></div>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group"><textarea class="form-control text-box" rows="3" id="exttransactiondetails" name="external transaction details" placeholder="Transaction Details"></textarea></div>
                                                    </div>
                                                </div>
                                                <div class="form-row text-center spacer">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <div class="form-check"><input class="form-check-input" type="checkbox" id="extterms" name="terms"><label class="form-check-label agree-box" for="formCheck-2">Agree to our Terms &amp; Conditions</label></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-row text-center spacer">
                                                    <div class="col">
                                                        <div class="form-group"><button class="btn btn-primary btn3" type="submit">Make Transfer</button></div>
                                                    </div>
                                                </div>
                                            </div>
                                            </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4"><div class="card card2 hover">
                        <div class="card-body">
                            <p class="text-right admin-p">Account Balance</p>
                            <h6 class="pull-left"><i class="la la-users icon1"></i></h6>
                            <h3 class="text-right admin-heading"><?php echo $symbol.$display_cu_balance; ?></h3>

                        </div>
                    </div></div>
            </div>
        </div>
    </div>
<?php 
include 'includes/footer.php';
include 'includes/validation.php';
?>
</body>

</html>
