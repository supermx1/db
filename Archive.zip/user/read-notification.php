<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'../classes/profile.php';
include'includes/session.php';
include'includes/header.php';
$notification_id = $_GET['notification_id'];
$query = $connect->query("SELECT * FROM arknotification WHERE arknotification_id = '$notification_id'");
if($query->rowCount() >= 1)
    {
        foreach($query as $row)
            {
                $message = $row['message'];
                $title = $row['title'];
                $datetime = $row['datetime'];
            }
    }
?>
<body class="body">
    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">
            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col"><button class="btn btn-primary pull-right btn1" type="button"><i class="la la-support btn-icon"></i>Contact Support</button>
                    <h4 class="main-col-row1-heading">Notifications</h4>
                    <p class="main-col-row1-p">You are on the notifications page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-12">
                    <div class="card card2">
                        <div class="card-body">
                            <h5 class="read-notifications-title">
                                <?php echo $title; ?>
                            </h5>
                            <hr>
                            <p class="read-notifications-p">
                                <?php echo $message; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'includes/footer.php';?>
</body>
</html>