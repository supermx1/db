<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'../classes/profile.php';
include'includes/session.php';
include'includes/header.php';
include'../settings.php';
?>

<body class="body">

    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">

            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col"><button class="btn btn-primary pull-right btn1" type="button"><i class="la la-support btn-icon"></i>Contact Support</button>
                    <h4 class="main-col-row1-heading">Statement</h4>
                    <p class="main-col-row1-p">You are on the statement page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-12">
                    <div class="card card2">
                        <div class="card-body">
                            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Reference</th>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>TX Details</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $query = $connect->query("SELECT * FROM arktransactions WHERE customer_number = '$current_user->customer_number' ORDER BY datetime DESC");
                                        if($query->rowCount() >= 1)
                                            {
                                                $x = 1;
                                                foreach($query as $row)
                                                    {
                                                        $arktransaction_id = $row['arktransaction_id'];
                                                        $details = $row['details'];
                                                        $amount = $row['amount'];
                                                        $datetime = $row['datetime'];
                                                        $display_amount = number_format($amount);
                                                        $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                        $status = $row['status'];
                                                        if($status == 0)
                                                            {
                                                                echo"
                                                                <tr>
                                                                    <td>$x</td>
                                                                    <td>$arktransaction_id</td>
                                                                    <td>$ddatetime</td>
                                                                    <td>$symbol$display_amount</td>
                                                                    <td>$details</td>
                                                                    <td><span class='badge badge-pill badge-info'>Pending</span></td>
                                                                </tr>
                                                                ";
                                                            }
                                                        else
                                                            {
                                                                echo"
                                                                <tr>
                                                                    <td>$x</td>
                                                                    <td>$arktransaction_id</td>
                                                                    <td>$ddatetime</td>
                                                                    <td>$symbol$display_amount</td>
                                                                    <td>$details</td>
                                                                    <td><span class='badge badge-pill badge-success'>Success</span></td>
                                                                </tr>
                                                                ";
                                                            }
                                                    $x++;
                                                    }
                                            }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include 'includes/footer.php';?>
</body>
</html>