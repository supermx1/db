<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'../classes/profile.php';
include'includes/session.php';
include'includes/header.php';
?><body class="body">
    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">
            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col"><button class="btn btn-primary pull-right btn1" type="button"><i class="la la-support btn-icon"></i>Contact Support</button>
                    <h4 class="main-col-row1-heading">Notifications</h4>
                    <p class="main-col-row1-p">You are on the notifications page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-12">
                    <div class="card card2">
                        <div class="card-body">
                            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Message Title</th>
                                            <th>Date</th>
                                            <th>Manage</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $query = $connect->query("SELECT * FROM arknotification WHERE recipient = '' OR recipient = '$current_user->arkuserinfo_id'");
                                        if($query->rowCount() >= 1)
                                            {
                                                $x = 1;
                                                foreach($query as $row)
                                                    {
                                                        $arknotification_id = $row['arknotification_id'];
                                                        $message = $row['message'];
                                                        $title = $row['title'];
                                                        $datetime = $row['datetime'];
                                                        $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                        echo"
                                                        <tr>
                                                            <td>$x</td>
                                                            <td>$title</td>
                                                            <td>$ddatetime</td>
                                                            <td>
                                                                <div class='dropdown'> 
                                                                    <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Action <span class=''></span></button>
                                                                    <ul class='dropdown-menu'>
                                                                        <li><a href='read-notification.php?notification_id=$arknotification_id' class='nav-link dropdown-item'><i class='icon ion-information-circled dropdown-icon'></i> Read</a></li>
                                                                    </ul>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        ";
                                                    }
                                            }
                                        ?>
                                    </tbody>
                                </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'includes/footer.php';?>
</body>

</html>
