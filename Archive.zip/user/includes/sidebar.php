<div id="navmenu"></div>
<ul class="list-group">
    <li class="list-group-item text-center list-group-item1"><a href="index.php" class="link7"><i class="la la-dashboard navmenu-icon"></i>
            <p class="text-center navmenu-p">Dashboard</p>
        </a>
    </li>
    <li class="list-group-item text-center list-group-item1"><a href="transfers.php" class="link7"><i class="la la-exchange navmenu-icon"></i>
            <p class="text-center navmenu-p">Transfers</p>
        </a>
    </li>
    <li class="list-group-item text-center list-group-item1"><a href="cards.php" class="link7"><i class="la la-credit-card navmenu-icon"></i>
            <p class="text-center navmenu-p">Cards</p>
        </a>
    </li>
    <li class="list-group-item text-center list-group-item1"><a href="statement.php" class="link7"><i class="la la-pie-chart navmenu-icon"></i>
            <p class="text-center navmenu-p">Statement</p>
        </a>
    </li>
    <li class="list-group-item text-center list-group-item1"><a href="profile.php" class="link7"><i class="la la-user navmenu-icon"></i>
            <p class="text-center navmenu-p">Profile</p>
        </a>
    </li>
</ul>
