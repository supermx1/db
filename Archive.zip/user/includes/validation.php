<script>
    $("#changepassword_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("old_password");
        inputs[1] = document.getElementById("new_password");
        inputs[2] = document.getElementById("confirm_password");
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Password successfully changed');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#edit_profile_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("firstname");
        inputs[1] = document.getElementById("lastname");
        inputs[2] = document.getElementById("gender");
        inputs[3] = document.getElementById("dob");
        inputs[4] = document.getElementById("email");
        inputs[5] = document.getElementById("contact");
        inputs[6] = document.getElementById("address");
        inputs[7] = document.getElementById("city");
        inputs[8] = document.getElementById("state");
        inputs[9] = document.getElementById("country");
        
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        var validate_email = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var email = document.getElementById("email");

        if(email.value !== '')
			{
				if(validate_email.test(email.value) === true)
					{
						
					}
				else
					{
						email.style.background = "#ffcccc";
						toastr.error(email.name + ' is not a valid email address');
						res = false;
					}
			}
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Profile successfully edited');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#validate_account_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("nationalid");
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        var terms = document.getElementById('terms');
		if(terms.checked)
			{
			
			}
		else
			{
				toastr.error('You have to agree to our ' + terms.name + ' to verify your account');
				res = false;
			}
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Account validation request successfully sent');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#card_request_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("cardtype");
        inputs[1] = document.getElementById("instruction");
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        var terms = document.getElementById('terms');
		if(terms.checked)
			{
			
			}
		else
			{
				toastr.error('You have to agree to our ' + terms.name + ' to request for a card');
				res = false;
			}
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Card request successfully sent');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#internal_transfer_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("accountnumber");
        inputs[1] = document.getElementById("account");
        inputs[2] = document.getElementById("amount");
        inputs[3] = document.getElementById("transactiondetails");
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        var terms = document.getElementById('terms');
		if(terms.checked)
			{
			
			}
		else
			{
				toastr.error('You have to agree to our ' + terms.name + ' to initiate a transfer');
				res = false;
			}
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							toastr.success('Transaction successful');
							setTimeout(function(){
							window.location.href= 'statement.php';},3000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#extfundstransfer_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("bankname");
        inputs[1] = document.getElementById("extaccountnumber");
        inputs[2] = document.getElementById("confirmaccountnumber");
        inputs[3] = document.getElementById("beneficiaryname");
        inputs[4] = document.getElementById("swiftbic");
        inputs[5] = document.getElementById("abartn");
        inputs[6] = document.getElementById("accounttype");
        inputs[7] = document.getElementById("extamount");
        inputs[8] = document.getElementById("exttransactiondetails");
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        var terms = document.getElementById('extterms');
		if(terms.checked)
			{
			
			}
		else
			{
				toastr.error('You have to agree to our ' + terms.name + ' to initiate a transfer');
				res = false;
			}
		
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							var transaction_id = data.transaction_id;
                            toastr.info('Transaction processing, please wait');
							setTimeout(function(){
							window.location.href= 'vcode.php?transaction_id='+transaction_id;},3000);
						}else if (data.status === 'success2'){
                            toastr.success('Transaction verification successful, processing transaction');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
                        }else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#transactionverification_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("verificationcode");
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
		if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							var transaction_id = data.transaction_id;
                            toastr.success('Transaction verification successful, processing transaction');
							setTimeout(function(){
							window.location.href= 'vcode.php?transaction_id='+transaction_id;},3000);
						}else if (data.status === 'success2'){
                            var transaction_id = data.transaction_id;
                            toastr.success('Transaction verification successful, processing transaction');
							setTimeout(function(){
							window.location.href= 'index.php';},3000);
                        }else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>