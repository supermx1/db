<?php
$config = parse_ini_file("../../../config.ini");
include'../../includes/connect.php';
include'../../classes/users.php';
include'../../classes/profile.php';
include'session.php';
$logdatetime = time();
function generateRandomStringLog($length = 15) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
$arklog_id = generateRandomStringLog();

if(isset($_POST['confirm_new_password']))
{
    $password = addslashes(strip_tags($_POST['password']));
    $new_password = addslashes(strip_tags($_POST['new_password']));
    $confirm_new_password = addslashes(strip_tags($_POST['confirm_new_password']));
    if($password == $current_user->password)
		{
			if($new_password == $confirm_new_password)
				{
					$query = $connect->query("UPDATE arkuserinfo SET password = '$new_password' WHERE arkuserinfo_id = '$current_user->arkuserinfo_id'");
                    $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Password Changed by User','$logdatetime')");
					$response['status'] = "success";
					echo json_encode($response);
				}
			else
				{
					echo json_encode("Passwords entered don't match");
				}
		}
	else
		{
			echo json_encode("Wrong password entered");
		}
}

if(isset($_POST['date_of_birth']))
{
    $date_of_birth = addslashes(strip_tags($_POST['date_of_birth']));
    $first_name = addslashes(strip_tags($_POST['first_name_profile']));
    $last_name = addslashes(strip_tags($_POST['last_name_profile']));
    $gender = addslashes(strip_tags($_POST['gender']));
    $email = addslashes(strip_tags($_POST['email']));
    $contact = addslashes(strip_tags($_POST['contact']));
    $address = addslashes(strip_tags($_POST['address']));
    $city = addslashes(strip_tags($_POST['city']));
    $state = addslashes(strip_tags($_POST['state']));
    $country = addslashes(strip_tags($_POST['country']));
    $query = $connect->query("UPDATE arkuserinfo SET first_name = '$first_name', last_name = '$last_name', gender = '$gender', dob = '$date_of_birth', contact = '$contact', address = '$address', city = '$city', state = '$state', country = '$country' WHERE arkuserinfo_id = '$current_user->arkuserinfo_id'");
    $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Profile Updated by User','$logdatetime')");
    $response['status'] = "success";
    echo json_encode($response);
}

if(isset($_POST['identification_number']))
{
    function generateRandomString($length = 15) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
    $arkaccountvalidation_id = generateRandomString();
    $datetime = time();
    $identification_number = addslashes(strip_tags($_POST['identification_number']));
    $other_information = addslashes(strip_tags($_POST['other_information']));
    
    $query = $connect->query("SELECT * FROM arkaccountvalidation WHERE customer_number='$current_user->customer_number' AND status = '0'");
    if($query->rowCount() >= 1)
		{
            echo json_encode("Pending validation request");
        }
    else
        {
            $query = $connect->query("INSERT INTO arkaccountvalidation VALUES('$arkaccountvalidation_id','$current_user->customer_number','$identification_number','$other_information','$datetime','0')");
            $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Account Validation Request Sent by User','$logdatetime')");
            $response['status'] = "success";
            echo json_encode($response);
        }
}

if(isset($_POST['card_type']))
{
    function generateRandomString($length = 15) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
    $arkcardrequest_id = generateRandomString();
    $datetime = time();
    $card_type = addslashes(strip_tags($_POST['card_type']));
    $instruction = addslashes(strip_tags($_POST['instruction']));
    $query = $connect->query("SELECT * FROM arkcardrequest WHERE customer_number='$current_user->customer_number' AND status = '0'");
    if($query->rowCount() >= 1)
		{
            echo json_encode("Pending card request");
        }
    else
        {
            $query = $connect->query("INSERT INTO arkcardrequest VALUES('$arkcardrequest_id','$current_user->customer_number','$card_type','$instruction','$datetime','0')");
            $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Card Request Sent by User','$logdatetime')");
            $response['status'] = "success";
            echo json_encode($response);
        }
}






/// User Transaction List

if(isset($_POST['account_number']))
{
    function generateRandomString($length = 15) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
    $arktransaction_id = generateRandomString();
    function generateRandomString1($length = 15) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
    $arktransaction_id1 = generateRandomString1();
    $datetime = time();
    $account_number = addslashes(strip_tags($_POST['account_number']));
    $amount = addslashes(strip_tags($_POST['amount']));
    $transaction_details = addslashes(strip_tags($_POST['transaction_details']));
    $inward_details = "Funds Received - ".$transaction_details;
    $outward_details = "Funds Transfered - ".$transaction_details;
    $query = $connect->query("SELECT * FROM arkaccountinfo WHERE account_number='$account_number' AND customer_number != '$current_user->customer_number'");
    if($query->rowCount() >= 1)
		{
            foreach($query as $row)
                {
                    $balance = $row['balance'];
                    $arkaccountinfo_id = $row['arkaccountinfo_id'];
                    $customer_number = $row['customer_number'];
                }
            $query1 = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$current_user->customer_number'");
            foreach($query1 as $row1)
                {
                    $cu_balance = $row1['balance'];
                    $cu_arkaccountinfo_id = $row1['arkaccountinfo_id'];
                }
            if($cu_balance > $amount)
                {
                    $cu_new_balance = $cu_balance - $amount;
                    $new_balance = $balance + $amount;
                    $query = $connect->query("UPDATE arkaccountinfo SET balance = '$cu_new_balance' WHERE arkaccountinfo_id = '$cu_arkaccountinfo_id'");
                    $query = $connect->query("UPDATE arkaccountinfo SET balance = '$new_balance' WHERE arkaccountinfo_id = '$arkaccountinfo_id'");
                    $query = $connect->query("INSERT INTO arktransactions VALUES('$arktransaction_id','$current_user->customer_number','$outward_details','$amount','2','$datetime','1')");
                    $query = $connect->query("INSERT INTO arktransactions VALUES('$arktransaction_id1','$customer_number','$inward_details','$amount','1','$datetime','1')");
                    $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','InterBank Transfer Carried Out by User','$logdatetime')");
                    $response['status'] = "success";
                    echo json_encode($response);
                }
            else
                {
                    echo json_encode("Insufficient funds");
                }
        }
    else
        {
            echo json_encode("Invalid account number");
        }
}

if(isset($_POST['transaction_verification_code']))
{
    $transaction_verification_code = addslashes(strip_tags($_POST['transaction_verification_code']));
    $transaction_id = addslashes(strip_tags($_POST['transaction_id']));
    $query = $connect->query("SELECT * FROM arkexttransfercode WHERE arkexttransfercode_id = '$transaction_id'");
    if($query->rowCount() >= 1)
		{
            foreach($query as $row)
                {
                    $code = $row['code'];
                    $codestatus = $row['codestatus'];
                    $code1 = $row['code1'];
                    $code1status = $row['code1status'];
                    $code2 = $row['code2'];
                    $code2status = $row['code2status'];
                    $code3 = $row['code3'];
                    $code3status = $row['code3status'];
                    $code4 = $row['code4'];
                    $code4status = $row['code4status'];
                }
            if($codestatus == 0)
                {
                    if($code == $transaction_verification_code)
                        {
                            $query = $connect->query("UPDATE arkexttransfercode SET codestatus = '1' WHERE arkexttransfercode_id = '$transaction_id'");
                            $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Verification Code 1 Entered by User','$logdatetime')");
                            $response['transaction_id'] = $transaction_id;
                            $response['status'] = "success";
                            echo json_encode($response);
                        }
                    else
                        {
                            echo json_encode("Invalid transaction verification code");
                        }
                }
            elseif($code1status == 0 && $codestatus == 1)
                {
                    if($code1 == $transaction_verification_code)
                        {
                            $query = $connect->query("UPDATE arkexttransfercode SET code1status = '1' WHERE arkexttransfercode_id = '$transaction_id'");
                            $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Verification Code 2 Entered by User','$logdatetime')");
                            $response['transaction_id'] = $transaction_id;
                            $response['status'] = "success";
                            echo json_encode($response);
                        }
                    else
                        {
                            echo json_encode("Invalid transaction verification code");
                        }
                }
            elseif($code2status == 0 && $code1status == 1)
                {
                    if($code2 == $transaction_verification_code)
                        {
                            $query = $connect->query("UPDATE arkexttransfercode SET code2status = '1' WHERE arkexttransfercode_id = '$transaction_id'");
                            $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Verification Code 3 Entered by User','$logdatetime')");
                            $response['transaction_id'] = $transaction_id;
                            $response['status'] = "success";
                            echo json_encode($response);
                        }
                    else
                        {
                            echo json_encode("Invalid transaction verification code");
                        }
                }
            elseif($code3status == 0 && $code2status == 1)
                {
                    if($code3 == $transaction_verification_code)
                        {
                            $query = $connect->query("UPDATE arkexttransfercode SET code3status = '1' WHERE arkexttransfercode_id = '$transaction_id'");
                            $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Verification Code 4 Entered by User','$logdatetime')");
                            $response['transaction_id'] = $transaction_id;
                            $response['status'] = "success";
                            echo json_encode($response);
                        }
                    else
                        {
                            echo json_encode("Invalid transaction verification code");
                        }
                }
            elseif($code4status == 0 && $code3status == 1)
                {
                    if($code4 == $transaction_verification_code)
                        {
                            $query = $connect->query("UPDATE arkexttransfercode SET code4status = '1' WHERE arkexttransfercode_id = '$transaction_id'");
                            $query = $connect->query("UPDATE arktransactions SET status = '1' WHERE arktransaction_id = '$transaction_id'");
                            $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','Verification Code 5 Entered by User','$logdatetime')");
                            $response['status'] = "success2";
                            echo json_encode($response);
                        }
                    else
                        {
                            echo json_encode("Invalid transaction verification code");
                        }
                }
            else
                {
                    echo json_encode("Unknown error, please contact administrator");
                }
        }
    else
        {
            echo json_encode("Invalid transaction code");
        }
}









// Show Pending Transactions
// Transfer to External Bank

if(isset($_POST['bank_name']))
{
    $querycheck = $connect->query("SELECT * FROM arktransactions WHERE customer_number = '$current_user->customer_number' AND status = '0'");
    if($querycheck->rowCount() >= 2)
		{
            echo json_encode("You have two pending transaction, please conclude your existing transaction to initiate a new transaction");
        }
    else
        {
            function generateRandomString($length = 15) 
            {
                $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $charactersLength = strlen($characters);
                $randomString = '';
                for ($i = 0; $i < $length; $i++) 
                    {
                        $randomString .= $characters[rand(0, $charactersLength - 1)];
                    }
                return $randomString;
            }
            $arktransaction_id = generateRandomString();
            $datetime = time();
            $bank_name = addslashes(strip_tags($_POST['bank_name']));
            $external_account_number = addslashes(strip_tags($_POST['external_account_number']));
            $confirm_account_number = addslashes(strip_tags($_POST['confirm_account_number']));
            $beneficiary_name = addslashes(strip_tags($_POST['beneficiary_name']));
            $swift_bic = addslashes(strip_tags($_POST['swift_bic']));
            $aba_rtn = addslashes(strip_tags($_POST['aba_rtn']));
            $account_type = addslashes(strip_tags($_POST['account_type']));
            $transfer_amount = addslashes(strip_tags($_POST['transfer_amount']));
            $external_transaction_details = addslashes(strip_tags($_POST['external_transaction_details']));
            $vcode = rand(12345,54321);
            $vcode1 = rand(12345,54321);
            $vcode2 = rand(12345,54321);
            $vcode3 = rand(12345,54321);
            $vcode4 = rand(12345,54321);
            
            if($current_user->codestatus == 0)
                {
                    //Check if account number matches
                    if($external_account_number == $confirm_account_number)
                        {
                            $query1 = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$current_user->customer_number'");
                            foreach($query1 as $row1)
                                {
                                    $cu_balance = $row1['balance'];
                                    $cu_arkaccountinfo_id = $row1['arkaccountinfo_id'];
                                }
                                //Check if current bank balance is greater
                            if($cu_balance > $transfer_amount)
                                {
                                    $transaction_details = "Bank: ".$bank_name." Account Number: ".$external_account_number." Beneficiary Name: ".$beneficiary_name." SWIFT/BIC: ".$swift_bic." ABA/RTN: ".$aba_rtn." - ".$external_transaction_details;
                                    $cu_new_balance = $cu_balance - $transfer_amount;
                                    $query = $connect->query("UPDATE arkaccountinfo SET balance = '$cu_new_balance' WHERE arkaccountinfo_id = '$cu_arkaccountinfo_id'");
                                    $query = $connect->query("INSERT INTO arktransactions VALUES('$arktransaction_id','$current_user->customer_number','$transaction_details','$transfer_amount','3','$datetime','0')");
                                    $query = $connect->query("INSERT INTO arkexttransfercode VALUES('$arktransaction_id','$vcode','0','$vcode1','0','$vcode2','0','$vcode3','0','$vcode4','0')");
                                    $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','External Bank Transfer Initiated by User','$logdatetime')");
                                    $response['transaction_id'] = $arktransaction_id;
                                    $response['status'] = "success";
                                    echo json_encode($response);
                                }
                            else
                                {
                                    //Fail if account balance is low
                                    echo json_encode("Insufficient funds");
                                }
                        }
                    else
                        {
                            echo json_encode("Account numbers don't match, please check and input correctly");
                        }
                }
            else
                {
                    if($external_account_number == $confirm_account_number)
                        {
                            $query1 = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$current_user->customer_number'");
                            foreach($query1 as $row1)
                                {
                                    $cu_balance = $row1['balance'];
                                    $cu_arkaccountinfo_id = $row1['arkaccountinfo_id'];
                                }
                                
                            if($cu_balance > $transfer_amount)
                                {
                                    $transaction_details = "Bank: ".$bank_name." Account Number: ".$external_account_number." Beneficiary Name: ".$beneficiary_name." SWIFT/BIC: ".$swift_bic." ABA/RTN: ".$aba_rtn." - ".$external_transaction_details;
                                    $cu_new_balance = $cu_balance - $transfer_amount;
                                    $query = $connect->query("UPDATE arkaccountinfo SET balance = '$cu_new_balance' WHERE arkaccountinfo_id = '$cu_arkaccountinfo_id'");
                                    $query = $connect->query("INSERT INTO arktransactions VALUES('$arktransaction_id','$current_user->customer_number','$transaction_details','$transfer_amount','3','$datetime','1')");// THIS WAS CHANGED TO 0 FROM 1
                                    $query = $connect->query("INSERT INTO arkexttransfercode VALUES('$arktransaction_id','$vcode','1','$vcode1','1','$vcode2','1','$vcode3','1','$vcode4','1')");
                                    $query = $connect->query("INSERT INTO arklog VALUES('$arklog_id','$current_user->customer_number','External Bank Transfer Initiated by User','$logdatetime')");
                                    $response['transaction_id'] = $arktransaction_id;
                                    $response['status'] = "success2";
                                    echo json_encode($response);
                                }
                            else
                                {
                                    echo json_encode("Insufficient funds");
                                }
                                
                        }
                    else
                        {
                            echo json_encode("Account numbers don't match, please check and input correctly");
                        }
                }
            
            
        }
}
