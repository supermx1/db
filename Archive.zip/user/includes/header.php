<?php include '../settings.php' ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Banking</title>
    <meta property="og:title" content="Ace Trust Bank">
    <link rel="shortcut icon" type="image/png" sizes="500x500" href="">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="../assets/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="../assets/fonts/simple-line-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karla:400,400i,700,700i">
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/hover.css">
    <link rel="stylesheet" href="../assets/css/toastr.css">
    <link rel="stylesheet" href="../assets/css/normalize.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="../assets/datatables.net/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="../assets/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    <link rel="stylesheet" href="../assets/datatables.net/Buttons-1.5.1/css/buttons.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/datatables.net/Buttons-1.5.1/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="../assets/datatables.net/Responsive-2.2.1/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="../assets/datatables.net/Responsive-2.2.1/css/responsive.dataTables.min.css">

</head>
<style>
    .list-group-item1:hover>.link7 {
        color: #000 !important;
    }
    <?php echo $logosize ?>
    <?php echo $dashlogo ?>
</style>

