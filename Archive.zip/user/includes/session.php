<?php
if(isset($_SESSION['session_id']))
    {
        $current_user = new arkuser($_SESSION['session_id']);
        $query = $connect->query("SELECT * FROM arkprofilepicture WHERE arkuserinfo_id='$current_user->arkuserinfo_id'");
        if($query->rowCount() >= 1)
            {
                $current_profile = new profilepicture($_SESSION['session_id']);
                $displaypp = $current_profile->profile;
            }
        else
            {
                $displaypp = "../assets/img/favicon.png";
            }
        if($current_user->acctype !== "2")
            {
                echo"<meta http-equiv='refresh' content='0;url=logout.php'>";
            }
    }
else
    {
        header('location: logout.php');
    }
?>