<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../assets/datatables.net/Buttons-1.5.1/js/dataTables.buttons.min.js"></script>
<script src="../assets/datatables.net/js/dataTables.bootstrap4.min.js"></script>

<script src="../assets/datatables.net/Responsive-2.2.1/js/dataTables.responsive.min.js"></script>
<script src="../assets/datatables.net/Responsive-2.2.1/js/responsive.bootstrap4.min.js"></script>

<script src="../assets/datatables.net/JSZip-2.5.0/jszip.min.js"></script>
<script src="../assets/datatables.net/pdfmake-0.1.32/pdfmake.min.js"></script>
<script src="../assets/datatables.net/pdfmake-0.1.32/vfs_fonts.js"></script>

<script src="../assets/datatables.net/Buttons-1.5.1/js/buttons.bootstrap4.min.js"></script>
<script src="../assets/datatables.net/Buttons-1.5.1/js/buttons.html5.min.js"></script>
<script src="../assets/datatables.net/Buttons-1.5.1/js/buttons.print.min.js"></script>
<script src="../assets/datatables.net/Buttons-1.5.1/js/buttons.colVis.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script src="../assets/js/zchart.js"></script>
<script src="../assets/js/zenable-tooltip.js"></script>
<script src="../assets/js/zscroll.js"></script>
<script src="../assets/js/zselect2.js"></script>
<script src="../assets/js/toastr.js"></script>
<script>
    $(document).ready(function() {
        $('#example').DataTable({
            "paging": true,
            "ordering": true,
            "info": false,
            "searching": true,
            "responsive": true,
            "language": {
                "decimal": ".",
                "thousands": ","
            },
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]

        });
    });

</script>
