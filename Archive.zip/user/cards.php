<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'../classes/profile.php';
include'includes/session.php';
include'includes/header.php';
?><body class="body">

    <?php include 'includes/nav.php';?>

    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">
            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col">
                    <a href="mailto:accounts@e-umb.online" class="btn btn-primary pull-right btn1" type="link"><i class="la la-support btn-icon"></i>Contact Support</a>
                    <h4 class="main-col-row1-heading">Cards</h4>
                    <p class="main-col-row1-p">You are on the cards page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-12">
                    <div class="card card2">
                        <div class="card-body">
                            <div>
                                <ul class="nav nav-pills">
                                    <li class="nav-item"><a class="nav-link active link2" role="tab" data-toggle="pill" href="#tab-4">All Cards</a></li>
                                    <li class="nav-item"><a class="nav-link link2" role="tab" data-toggle="pill" href="#tab-5">Request For Card</a></li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" role="tabpanel" id="tab-4">
                                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>S/N</th>
                                                        <th>Name</th>
                                                        <th>Date Ordered</th>
                                                        <th>Account</th>
                                                        <th>Status</th>
                                                        <th>Manage</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $query = $connect->query("SELECT * FROM arkcardrequest WHERE customer_number='$current_user->customer_number'");
                                                    if($query->rowCount() >= 1)
                                                        {
                                                            $x = 1;
                                                            foreach($query as $row)
                                                                {
                                                                    $arkcardrequest_id = $row['arkcardrequest_id'];
                                                                    $cardtype = $row['cardtype'];
                                                                    $instruction = $row['instruction'];
                                                                    $status = $row['status'];
                                                                    $datetime = $row['datetime'];
                                                                    $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                                    if($status == 0)
                                                                        {
                                                                            echo"
                                                                            <tr>
                                                                                <td>$x</td>
                                                                                <td>$current_user->first_name $current_user->last_name</td>
                                                                                <td>$ddatetime</td>
                                                                                <td>USD ($)</td>
                                                                                <td><span class='badge badge-pill badge-info'>Pending</span></td>
                                                                                <td>
                                                                                    <div class='dropdown'> 
                                                                                        <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Action <span class=''></span></button>
                                                                                        <ul class='dropdown-menu'>
                                                                                            <li><a href='cancelcard.php?cardrequest_id=$arkcardrequest_id' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Cancel Card</a></li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </td>
                                                                            </tr>
                                                                            ";
                                                                        }
                                                                    elseif($status == 1)
                                                                        {
                                                                            echo"
                                                                            <tr>
                                                                                <td>$x</td>
                                                                                <td>$current_user->first_name $current_user->last_name</td>
                                                                                <td>$ddatetime</td>
                                                                                <td>USD ($)</td>
                                                                                <td><span class='badge badge-pill badge-success'>Success</span></td>
                                                                                <td>
                                                                                    <div class='dropdown'> 
                                                                                        <button class='btn btn-primary dropdown-toggle btn1' type='button' data-toggle='dropdown'>Action <span class=''></span></button>
                                                                                        <ul class='dropdown-menu'>
                                                                                            <li><a href='cancelcard.php?cardrequest_id=$arkcardrequest_id' class='nav-link dropdown-item'><i class='icon ion-android-cancel dropdown-icon'></i> Cancel Card</a></li>
                                                                                        </ul>
                                                                                    </div>
                                                                                </td>
                                                                            </tr>
                                                                            ";
                                                                        }
                                                                    else
                                                                        {
                                                                            echo"
                                                                            <tr>
                                                                                <td>$x</td>
                                                                                <td>$current_user->first_name $current_user->last_name</td>
                                                                                <td>$ddatetime</td>
                                                                                <td>USD ($)</td>
                                                                                <td><span class='badge badge-pill badge-danger'>Canceled</span></td>
                                                                                <td>N/A</td>
                                                                            </tr>
                                                                            ";
                                                                        }
                                                                    $x++;
                                                                }
                                                        }
                                                    ?>
                                                </tbody>
                                            </table>
                                    </div>
                                    <div class="tab-pane fade" role="tabpanel" id="tab-5">
                                        <form id="card_request_form">
                                            <div class="trans-form">
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <select class="form-control text-box" id="cardtype" name="card type">
                                                                <optgroup label="Card Type">
                                                                    <option value="" selected="">- Select Card Type -</option>
                                                                    <option value="Gold Card">Gold Card</option>
                                                                    <option value="Platnium Card">Platnium Card</option>
                                                                </optgroup>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col">
                                                        <div class="form-group"><input class="form-control text-box" type="text" disabled="" placeholder="Name on Card" value="<?php echo $current_user->first_name." ".$current_user->last_name; ?>"></div>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                    <div class="col">
                                                        <div class="form-group"><textarea class="form-control text-box" rows="3" placeholder="Further Instructions" id="instruction" name="instruction"></textarea></div>
                                                    </div>
                                                </div>
                                                <div class="form-row text-center spacer">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <div class="form-check"><input class="form-check-input" type="checkbox" id="terms" name="terms"><label class="form-check-label agree-box" for="formCheck-1">Agree to our Terms &amp; Conditions</label></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-row text-center spacer">
                                                    <div class="col">
                                                        <div class="form-group"><button class="btn btn-primary btn3" type="submit">Request For Card</button></div>
                                                    </div>
                                                </div>
                                            </div>
                                            </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php 
include 'includes/footer.php';
include 'includes/validation.php';
?>
</body>
</html>