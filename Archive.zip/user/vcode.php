<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'../classes/profile.php';
include'includes/session.php';
include'includes/header.php';

$transaction_id = $_GET['transaction_id'];
$query = $connect->query("SELECT * FROM arkexttransfercode WHERE arkexttransfercode_id = '$transaction_id'");
if($query->rowCount() >= 1)
	{
        foreach($query as $row)
            {
                $code = $row['code'];
                $codestatus = $row['codestatus'];
                $code1 = $row['code1'];
                $code1status = $row['code1status'];
                $code2 = $row['code2'];
                $code2status = $row['code2status'];
            }
        if($codestatus == 0)
            {
                $headtext = "Transfer Authorization Code";
            }
        elseif($code1status == 0 && $codestatus == 1)
            {
                $headtext = "Tax Code";
            }
        elseif($code2status == 0 && $code1status == 1)
            {
                $headtext = "Money Laundering Code";
            }
        elseif($code3status == 0 && $code1status == 1)
            {
                $headtext = "Currency Conversion";
            }
        elseif($code4status == 0 && $code1status == 1)
            {
                $headtext = "Final Transfer Code";
            }
        else
            {
                echo json_encode("Unknown error, please contact administrator");
            }
    }
?>
<body class="body">

    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">

            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col"><button class="btn btn-primary pull-right btn1" type="button"><i class="la la-support btn-icon"></i>Contact Support</button>
                    <h4 class="main-col-row1-heading"><?php echo $headtext; ?></h4>
                    <p class="main-col-row1-p">You are on the verification page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-12">
                    <div class="card card2">
                        <div class="card-body">
                            <p class="text-center v-code-p">Please enter the <?php echo $headtext; ?> provided by the bank. if you don't know what that is please contact your account officer or chat with our customer care agent via <a href="https://tawk.to/chat/6188e8746bb0760a49419a31/1fjvco2l2" target="_blank">live chat.</a></p>
                            <form id="transactionverification_form">
                                <div class="trans-form">
                                    <div class="form-row">
                                        <div class="col">
                                            <div class="form-group"><input class="form-control text-box" type="text" id="verificationcode" name="transaction verification code" placeholder="Enter Code"></div>
                                            <input type="hidden" name="transaction_id" value="<?php echo $transaction_id; ?>">
                                        </div>
                                    </div>
                                    <div class="form-row text-center spacer">
                                        <div class="col"><button class="btn btn-primary btn3" type="submit">Confirm &amp; Proceed</button></div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php 
include 'includes/footer.php';
include 'includes/validation.php';
?>
</body>
</html>