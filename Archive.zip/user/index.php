<?php
$config = parse_ini_file("../../config.ini");
include'../includes/connect.php';
include'../classes/users.php';
include'../classes/profile.php';
include'includes/session.php';
include'includes/header.php';
include'../settings.php';

$query1 = $connect->query("SELECT * FROM arkaccountinfo WHERE customer_number = '$current_user->customer_number'");
foreach($query1 as $row1)
    {
        $cu_balance = $row1['balance'];
        $cu_account_number = $row1['account_number'];
    }
$display_cu_balance = number_format($cu_balance);

$querysent = $connect->query("SELECT SUM(amount) AS amount_sent FROM arktransactions WHERE type = '2' OR type = '3' AND customer_number = '$current_user->customer_number'");
foreach($querysent as $rowsent)
    {
        $amount_sent = $rowsent['amount_sent'];
    }
if($amount_sent == "")
    {
        $amount_sent_display = 0;
    }
else
    {
        $amount_sent_display = number_format($amount_sent);
    }

$queryreceived = $connect->query("SELECT SUM(amount) AS amount_received FROM arktransactions WHERE type = '0' OR type = '1' AND customer_number = '$current_user->customer_number'");
foreach($queryreceived as $rowreceived)
    {
        $amount_received = $rowreceived['amount_received'];
    }
if($amount_received == "")
    {
        $amount_received_display = 0;
    }
else
    {
        $amount_received_display = number_format($amount_received);
    }
?>

<body class="body">
    <?php include 'includes/nav.php';?>
    <div class="row no-gutters dashboard-main-row">
        <div class="col-md-1" id="sidebar">
            <?php include 'includes/sidebar.php';?>
        </div>
        <div class="col" id="main-col">
            <div class="row" id="row1">
                <div class="col"><a class="btn btn-primary pull-right btn1" type="link" href="mailto:customercare@<?php echo $bankurl ?>" target="blank_"><i class="la la-support btn-icon"></i>Contact Support</a>
                    <h4 class="main-col-row1-heading">Dashboard</h4>
                    <p class="main-col-row1-p">You are on the dashboard page</p>
                </div>
            </div>
            <div class="row" id="row2">
                <div class="col-md-4 row3-col">
                    <div class="col-md-12">
                        <h6 class="dashboard-p"><i class="icon-pie-chart menu-item-icon"></i>Account Operations</h6>
                    <div class="card card2">
                        <div class="card-body">
                            <p class="text-right currency-p text-white"><?php echo $cu_account_number; ?></p>
                            <!---<h6 class="currency-heading pull-left"><img src="../assets/img/US.png" class="flag-img">USD</h6>-->
                            <h3 class="text-right currency-heading2 text-white"><?php echo $symbol ?><?php echo $display_cu_balance; ?></h3>
                            <p class="text-right currency-p"><?php echo $currency ?></p>
                        </div>
                    </div>
                    </div>
                    
                    <div class="col-md-12">
                    <h6 class="dashboard-p"><i class="icon-pie-chart menu-item-icon"></i>Recent Operations</h6>
                    <div class="card card2">
                        <div class="card-body">
                            <div class="table-responsive table-borderless dashboard-table">
                                <table class="table table-bordered table-hover">
                                    <tbody>
                                        <?php
                                            $query = $connect->query("SELECT * FROM arktransactions WHERE customer_number = '$current_user->customer_number' ORDER BY datetime DESC LIMIT 4");
                                            if($query->rowCount() >= 1)
                                                {
                                                    $x = 1;
                                                    foreach($query as $row)
                                                        {
                                                            $arktransaction_id = $row['arktransaction_id'];
                                                            $details = $row['details'];
                                                            $amount = $row['amount'];
                                                            $type = $row['type'];                                                            
                                                            if($type == 0)
                                                                {
                                                                    $heading = "Deposit"; 
                                                                    $arrowdisplay = "<i class='la la-arrow-right tx-icon'></i>";
                                                                }
                                                            elseif($type == 1)
                                                                {
                                                                    $heading = "Funds Received";
                                                                    $arrowdisplay = "<i class='la la-arrow-right tx-icon'></i>";
                                                                }
                                                            elseif($type == 2)
                                                                {
                                                                    $heading = "INTERBNK Outward Transfer";
                                                                    $arrowdisplay = "<i class='la la-arrow-left tx-icon2'></i>";
                                                                }
                                                            else
                                                                {
                                                                    $heading = "EXTBANK Outward Transfer";
                                                                    $arrowdisplay = "<i class='la la-arrow-left tx-icon2'></i>";
                                                                }
                                                            $display_amount = number_format($amount);
                                                            $datetime = $row['datetime'];
                                                            $status = $row['status'];
                                                            $display_amount = number_format($amount);
                                                            $ddatetime = gmdate("F j, Y, g:i A", "$datetime");
                                                            if($status == 0)
                                                                {
                                                                    //pending
                                                                    echo"
                                                                    <tr>
                                                                        <td>$x</td>
                                                                        <td>
                                                                            <p class='tx-p1'><a href='vcode.php?transaction_id=$arktransaction_id' class='tx-p5'>$heading</a></p>
                                                                            <p class='tx-p2'>$details</p>
                                                                            <p class='tx-p''>$ddatetime</p>
                                                                        </td>
                                                                        <td class='text-right'>
                                                                            <p class='tx-p3'>
                                                                                $arrowdisplay $symbol$display_amount
                                                                            </p>
                                                                            <span class='badge badge-pill badge-info tx-pill'>Pending</span>
                                                                        </td>
                                                                    </tr>
                                                                    ";
                                                                }
                                                            elseif($status == 1)
                                                                {
                                                                    //successful
                                                                    echo"
                                                                    <tr>
                                                                        <td>$x</td>
                                                                        <td>
                                                                            <p class='tx-p1'>$heading</p>
                                                                            <p class='tx-p2'>$details</p>
                                                                            <p class='tx-p''>$ddatetime</p>
                                                                        </td>
                                                                        <td class='text-right'>
                                                                            <p class='tx-p3'>
                                                                                $arrowdisplay $symbol$display_amount
                                                                            </p>
                                                                            <span class='badge badge-pill badge-success tx-pill'>Successful</span>
                                                                        </td>
                                                                    </tr>
                                                                    ";
                                                                }
                                                            else
                                                                {
                                                                    //canceled
                                                                    echo"
                                                                    <tr>
                                                                        <td>$x</td>
                                                                        <td>
                                                                            <p class='tx-p1'>$heading</p>
                                                                            <p class='tx-p2'>$details</p>
                                                                            <p class='tx-p''>$ddatetime</p>
                                                                        </td>
                                                                        <td class='text-right'>
                                                                            <p class='tx-p3'>
                                                                                $arrowdisplay $symbol$display_amount
                                                                            </p>
                                                                            <span class='badge badge-pill badge-danger tx-pill'>Canceled</span>
                                                                        </td>
                                                                    </tr>
                                                                    ";
                                                                }
                                                       
                                                        $x++;
                                                        }
                                                }
                                            ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-center"><a class="btn btn-primary btn2" type="link" href="statement.php">VIEW MORE</a></div>
                        </div>
                    </div>
                    </div>
                    
                    
                    
                    
                    
                    
                </div>
                <div class="col-md-4">
                    <h6 class="dashboard-p"><i class="icon-credit-card menu-item-icon"></i>Cards</h6>
                    <div class="card card2">
                        <div class="card-body">
                            <div class="mcard-align2">
                                <div class="mcard-align">
                                    <div class="mcard">
                                        <div class="mcard-logo"><img class="img-fluid" src="../assets/img/mcard-logo.png" width="50"></div>
                                        <div>
                                            <h5 class="text-center mcard-heading"><?php echo $cardnumber ?></h5>
                                        </div>
                                        <div class="row" id="row5">
                                            <div class="col mcard-col1">
                                                <p class="mcard-p">CARD HOLDER</p>
                                                <p class="mcard-p2"><?php echo $current_user->first_name." ".$current_user->last_name; ?></p>
                                            </div>
                                            <?php
                                            $cmonth = date('m');
                                            $cyear = date('y') + 2;
                                            $ccv = substr($current_user->customer_number,6);
                                            ?>
                                            <div class="col mcard-col2">
                                                <p class="mcard-p">VALID THRU</p>
                                                <p class="mcard-p2"><?php echo $cmonth."/".$cyear; ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" id="mcard-row2">
                                <div class="col">
                                    <p class="mcard-p3"><strong>Card Information</strong></p>
                                    <p class="mcard-p3">Debit</p>
                                    <p class="mcard-p3">Mastercard</p>
                                    <p class="mcard-p3">Savings Account</p>
                                </div>
                                <div class="col">
                                    <p class="mcard-p3"><strong>Status:</strong> <span class='badge badge-pill badge-info tx-pill'>Pending</span></p>
                                    <p class="mcard-p3"><strong>CVV2:</strong> <?php echo $ccv; ?></p>
                                    <div class="div-margin-top"><a class="btn btn-primary btn3" type="link" href="cards.php">ORDER CARD</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                <div class="col-md-4">
                    
                       <h6 class="dashboard-p"><i class="icon-graph menu-item-icon"></i>Market</h6>
                    <div class="card card2">
                        <div class="card-body">
                            <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-market-overview.js" async>
  {
  "showChart": true,
  "locale": "en",
  "largeChartUrl": "",
  "width": "100%",
  "height": "600",
  "plotLineColorGrowing": "rgba(60, 188, 152, 1)",
  "plotLineColorFalling": "rgba(255, 74, 104, 1)",
  "gridLineColor": "rgba(233, 233, 234, 1)",
  "scaleFontColor": "rgba(214, 216, 224, 1)",
  "belowLineFillColorGrowing": "rgba(60, 188, 152, 0.05)",
  "belowLineFillColorFalling": "rgba(255, 74, 104, 0.05)",
  "symbolActiveColor": "rgba(242, 250, 254, 1)",
  "tabs": [
    {
      "title": "Indices",
      "symbols": [
        {
          "s": "INDEX:SPX",
          "d": "S&P 500"
        },
        {
          "s": "INDEX:IUXX",
          "d": "Nasdaq 100"
        },
        {
          "s": "INDEX:DOWI",
          "d": "Dow 30"
        },
        {
          "s": "INDEX:NKY",
          "d": "Nikkei 225"
        },
        {
          "s": "INDEX:DAX",
          "d": "DAX Index"
        },
        {
          "s": "OANDA:UK100GBP",
          "d": "FTSE 100"
        }
      ],
      "originalTitle": "Indices"
    },
    {
      "title": "Commodities",
      "symbols": [
        {
          "s": "CME_MINI:ES1!",
          "d": "E-Mini S&P"
        },
        {
          "s": "CME:E61!",
          "d": "Euro"
        },
        {
          "s": "COMEX:GC1!",
          "d": "Gold"
        },
        {
          "s": "NYMEX:CL1!",
          "d": "Crude Oil"
        },
        {
          "s": "NYMEX:NG1!",
          "d": "Natural Gas"
        },
        {
          "s": "CBOT:ZC1!",
          "d": "Corn"
        }
      ],
      "originalTitle": "Commodities"
    },
    {
      "title": "Bonds",
      "symbols": [
        {
          "s": "CME:GE1!",
          "d": "Eurodollar"
        },
        {
          "s": "CBOT:ZB1!",
          "d": "T-Bond"
        },
        {
          "s": "CBOT:UD1!",
          "d": "Ultra T-Bond"
        },
        {
          "s": "EUREX:GG1!",
          "d": "Euro Bund"
        },
        {
          "s": "EUREX:II1!",
          "d": "Euro BTP"
        },
        {
          "s": "EUREX:HR1!",
          "d": "Euro BOBL"
        }
      ],
      "originalTitle": "Bonds"
    },
    {
      "title": "Forex",
      "symbols": [
        {
          "s": "FX:EURUSD"
        },
        {
          "s": "FX:GBPUSD"
        },
        {
          "s": "FX:USDJPY"
        },
        {
          "s": "FX:USDCHF"
        },
        {
          "s": "FX:AUDUSD"
        },
        {
          "s": "FX:USDCAD"
        }
      ],
      "originalTitle": "Forex"
    }
  ]
}
  </script>
</div>
<!-- TradingView Widget END -->
                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    </div>
    <?php include 'includes/footer.php';?>
</body>

</html>