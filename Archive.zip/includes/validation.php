<script>
    $("#login_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("customernumber");
        inputs[1] = document.getElementById("password");
        
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
							var db_type = data.acctype;
                            toastr.success('Login successfully, please wait to be redirected');
							if(db_type === "2")
								{
									setTimeout(function(){
									window.location.href= 'user/index.php';},3000);
								}
							else
								{
									setTimeout(function(){
									window.location.href= 'administrator/index.php';},3000);
								}
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>

<script>
    $("#userreg_form").submit(function(e)
    {
        toastr.info("Processing. Please wait");
        
		var inputs = [];
        var res = true;
        inputs[0] = document.getElementById("first_name");
        inputs[1] = document.getElementById("last_name");
        inputs[2] = document.getElementById("ssn");
        inputs[3] = document.getElementById("date_of_birth");
        inputs[4] = document.getElementById("address");
        inputs[5] = document.getElementById("city");
        inputs[6] = document.getElementById("state");
        inputs[7] = document.getElementById("zip_code");
        inputs[8] = document.getElementById("email_address");
        inputs[9] = document.getElementById("phone_number");
        
        for (i = 0; i < inputs.length; i++) {

            if (inputs[i].value === "")
				{

					inputs[i].style.background = "#ffcccc";
					res = false;
					toastr.error(inputs[i].name + ' must not be empty');
					
				} 
			else
				{
					inputs[i].style.background = "#fff";
				}
        }
        
        if (res === true)
			{ 
				data = $(this).serialize();	 
				$.ajax({
				type: "POST",
				dataType: "json",
				url: "includes/process.php", //Relative or absolute path to response.php file
				data: data,

				success: function(data) {
					if(data.status === 'success'){
                            toastr.success('Account created successfully, please wait to be redirected back to the login page. Our customer representatives will get in touch with you within 24 hours. Thank you for banking with us.');
							setTimeout(function(){
							window.location.href= 'index.php';},10000);
						}else {
							toastr.error(data);
						}
				}
				});
			}
		e.preventDefault();
    });
</script>