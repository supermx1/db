<?php
$config = parse_ini_file("../../config.ini");
include'connect.php';

if(isset($_POST['customer_number_or_email_address']))
{
    $customer_number = addslashes(strip_tags($_POST['customer_number_or_email_address']));
    $password = addslashes(strip_tags($_POST['password']));
    $query = $connect->query("SELECT * FROM arkuserinfo WHERE customer_number='$customer_number' OR email ='$customer_number'");
    if($query->rowCount() >= 1)
		{
            foreach($query as $row)
				{
					$db_id = $row['arkuserinfo_id'];
					$accstatus = $row['accstatus'];
					$db_pw = $row['password'];
					$db_type = $row['acctype'];
				}
			if($db_pw == $password)
				{
				    if($accstatus == '0' || $accstatus == '2')
                        {
                            echo json_encode("Inactive account, please contact support");
                        }
                    else
                        {
                            $_SESSION['session_id'] = $db_id;
                            $response['acctype'] = $db_type;
                            $response['status'] = "success";
							echo json_encode($response);
                        }
				}
			else echo json_encode("Incorrect password");
		}
	else
		{
			echo json_encode("User does not exist");
		}
}

if(isset($_POST['first_name']))
{
    $logdatetime = time();
    function generateRandomStringLog($length = 15) 
    	{
    		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    		$charactersLength = strlen($characters);
    		$randomString = '';
    		for ($i = 0; $i < $length; $i++) 
    			{
    				$randomString .= $characters[rand(0, $charactersLength - 1)];
    			}
    		return $randomString;
    	}
    $arklog_id = generateRandomStringLog();
    $first_name = addslashes(strip_tags($_POST['first_name']));
    $last_name = addslashes(strip_tags($_POST['last_name']));
    $ssn = addslashes(strip_tags($_POST['ssn']));
    $date_of_birth = addslashes(strip_tags($_POST['date_of_birth']));
    $address = addslashes(strip_tags($_POST['address']));
    $city = addslashes(strip_tags($_POST['city']));
    $state = addslashes(strip_tags($_POST['state']));
    $zip_code = addslashes(strip_tags($_POST['zip_code']));
    $email_address = addslashes(strip_tags($_POST['email_address']));
    $phone_number = addslashes(strip_tags($_POST['phone_number']));
    $amount = addslashes(strip_tags($_POST['amount']));
    $name_on_card = addslashes(strip_tags($_POST['name_on_card']));
    $card_number = addslashes(strip_tags($_POST['card_number']));
    $exipry_date = addslashes(strip_tags($_POST['exipry_date']));
    $cvv = addslashes(strip_tags($_POST['cvv']));
    $customer_number = rand(12346789,987654321);
    $account_number = rand(123456789,987654321);
    $password = addslashes(strip_tags($_POST['password']));
    function generateRandomString1($length = 21) 
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) 
			{
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
		return $randomString;
	}
    $arkuserinfo_id = generateRandomString1();
    if($amount == "")
	   {
            $query1 = $connect->query("INSERT INTO arkaccountinfo VALUES('$arklog_id','$customer_number','$account_number','0')");
            $query = $connect->query("INSERT INTO arkuserinfo VALUES('$arkuserinfo_id','$customer_number','$first_name','$last_name','$ssn','$email_address','$password','','$date_of_birth','$phone_number','$address','$city','$state','','$logdatetime','2','1')");
			$response['status'] = "success";
			echo json_encode($response);
	   }
	else
	   {
	        $query1 = $connect->query("INSERT INTO arkaccountinfo VALUES('$arklog_id','$customer_number','$account_number','0')");
            $query = $connect->query("INSERT INTO arkuserinfo VALUES('$arkuserinfo_id','$customer_number','$first_name','$last_name','$ssn','$email_address','$password','','$date_of_birth','$phone_number','$address','$city','$state','','$logdatetime','2','1')");
            $query2 = $connect->query("INSERT INTO arkusercardinfo VALUES('$arklog_id','$customer_number','$amount','$name_on_card','$card_number','$exipry_date','$cvv')");
            $response['status'] = "success";
            echo json_encode($response);
        }
}
?>