<?php include './settings.php'?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <title>Secure Access</title>
  <meta property="og:image" content="assets/img/favicon.png">
  <meta property="og:title" content="Ace Trust Bank">
  <link rel="icon" type="image/png" sizes="500x500" href="">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
  <link rel="stylesheet" href="assets/css/toastr.css">

</head>
<style>
  body {
    background: url("https://source.unsplash.com/user/danielsessler") center / cover;
  }

  .auth {
    background: #fff;
    width: 35%;
    /*margin: 0 auto;*/
    /*position: relative;*/
    /*top: 100px;*/
    padding: 1.2rem;
    align-items: center;
    justify-content: center;
    box-shadow: 0px 0px 20px 0px rgba(37, 37, 37, 0.04);
    border-radius: .3rem;
  }

  @media (max-width: 576px) {
    .auth {
      width: 90%;
    }
  }

  label {
    font-size: .7rem;
  }

  .btn1 {
    background-color: #000;
    color: #fff;
  }

  .btn1:hover {
    background-color: #000;
    color: #fff;
    cursor: pointer;
  }

  .link:hover {
    color: #000;
  }

  .link {
    color: black;
    font-size: 0.8rem;
  }

  .form-control:active,
  .form-control:focus {
    border: 1px solid #000 !important;
    box-shadow: none;
  }

  .form-control::placeholder {
    font-size: 0.8rem;
    font-weight: 200;
    font-style: italic;
    letter-spacing: 0.1rem;
  }
</style>

<body>
  <div class="container">
    <div class="row vh-100">
      <div class="col d-flex" style="align-items: center;justify-content: center;">
        <div class="auth">
          <div class="text-center">
             <?php echo $logo ?>
            <h5 class="mt-4 mb-4">Secure Sign In</h5>
          </div>
          <form id="login_form">
            <!-- Start: Drag and Drop File Input -->
            <div class="form-group"><label for="customernumber">Customer ID</label><input class="form-control" type="text" id="customernumber" name="customer number or email address" placeholder="Customer Number/Email"></div><!-- End: Drag and Drop File Input -->
            <!-- Start: Drag and Drop File Input -->
            <div class="form-group"><label for="password">Password</label><input class="form-control" type="password" id="password" name="password" placeholder="**********"></div><!-- End: Drag and Drop File Input -->
            <div class="form-group"><button class="btn btn-block btn1" type="submit">Sign In</button></div>
          </form>
          <div class="text-center" ce=""><a class="link" href="<?php echo $chat?>" target="_blank"><i class="fas fa-headset mr-2"></i>Customer Care</a></div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/Drag-and-Drop-File-Input.js"></script>
  <script src="assets/js/toastr.js"></script>
  <?php
  include 'includes/validation.php';
  ?>
</body>

</html>