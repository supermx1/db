
module.exports = async ({ action }, { services, getSchema, database: knex }) => {

    const schema = await getSchema();
    const { ItemsService } = services;
    const activity_items_service = new ItemsService('directus_activity', { knex, schema });

    action('server.start', async () => {
        activity_items_service.deleteByQuery({ limit: -1 })
    });

};
