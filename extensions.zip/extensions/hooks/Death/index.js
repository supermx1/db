module.exports = function registerHook({ filter }, { services, exceptions }) {
	const { InvalidPayloadException } = exceptions;
    const { ItemsService } = services;

	filter('items.create', async (input, { collection }, { schema }) => {
        if (collection !== 'death') return input;

        const deathItemsService = new ItemsService('death', {schema});
        const existingdeath = await deathItemsService.readByQuery({
            filter: {
                _and: [{ first_name: { _eq: input.first_name }, surname: { _eq: input.surname }, sex: { _eq: input.sex }, date_of_death: { _eq: input.date_of_death }, age_at_death: { _eq: input.age_at_death } }],
            },
        });

        if (existingdeath.length > 0) {
            throw new InvalidPayloadException('A similar death record already exists.');
        }

        return input;
	});

};



