module.exports = function registerHook({ filter }, { services, exceptions }) {

    const { InvalidPayloadException } = exceptions;
    const { ItemsService } = services;

    filter('live_birth.items.create', async (input, { collection }, { schema }) => {
        // if (collection !== 'live_birth') return input;

        const livebirthItemsService = new ItemsService('live_birth', { schema });
        const existinglivebirth = await livebirthItemsService.readByQuery({
            filter: {
                _and: [{ first_name: { _eq: input.first_name }, surname: { _eq: input.surname }, date_of_birth: { _eq: input.date_of_birth }, mother_maiden_name: { _eq: input.mother_maiden_name } }],
            },
        });

        if (existinglivebirth.length > 0) {
            console.log("existing live birth\n", input);
            throw new InvalidPayloadException('A person with this record or similar record already exists.')
        }

        return input;
    });

};