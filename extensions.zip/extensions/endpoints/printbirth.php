
<!-- Print Live Birth --->

<?php
date_default_timezone_set('Africa/Lagos');

$id = $_GET['id'];
  
// Username is root
$user = 'root';
$password = 'Admin08User'; 
  
// Database name is gfg
$database = 'vitalregdb'; 
  
// Server is localhost with
// port number 3308
$servername='localhost:3306';
$mysqli = new mysqli($servername, $user, 
                $password, $database);
  
// Checking for connections
if ($mysqli->connect_error) {
    die('Connect Error (' . 
    $mysqli->connect_errno . ') '. 
    $mysqli->connect_error);
}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Live Birth</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
    <link rel="shortcut icon" type="image/png" href="favicon.png"/>
    <link rel="icon" type="image/png" sizes="32x32" src="favicon.png">
</head>
<style>
        body p {
            font-weight:300;
        }
        .pull-right {
        float: right;
        }

        .box {
        display: block;
        border: 2px solid #000;
        }

        .box p {
        font-size: 14px;
        margin-bottom: 0;
        }

        .p-value {
        border-bottom: 2px solid #000;
        font-weight: 800;
        text-transform: uppercase;
        }
        
        .uppercase {
            text-transform: uppercase;
        }
        
        p {
          font-size: 1.7rem;
        }

        .table-p {
        margin-bottom: 0;
        }

        .table-borderless {
        border: none !important;
        }

        .blr {
        border-left: 2px solid #000;
        border-right: 2px solid #000;
        }

        .print-body {
        margin-top: 6rem;
        }
        .p-5 {
            padding: 3.65rem 3.8rem 3rem 3.8rem !important;
        }
</style>

<body class="p-5" style="margin-top:230px;">
        <!-- FETCH DATA FROM live_birth -->
        <?php   
        // LOOP TILL END OF DATA 
        // SQL query to select data from database
        $sql = 'SELECT * FROM live_birth WHERE id='.$id;
        $result = $mysqli->query($sql);
        while($rows=$result->fetch_assoc())
            {
                $status = $rows['status'];
                if($status == 2)
                    {
             ?>
    <div class="container bg p-5">
        <div class="row print-body">
            <div class="col-md-12 text-right">
                
            </div>
            <div class="col-md-7">
                <div class="row">
                    <div class="col-md-6">
                        <p class="table-p"><strong>Registration Centre</strong></p>
                    </div>
                    <div class="col-md-6 ">
                        <?php 
                        
                        $sqlupdate = "UPDATE live_birth SET print_count='1' WHERE id='$id'";
                        $resultupdate = $mysqli->query($sqlupdate);
                        $user_created = $rows['user_created'];
                        $sqlnew = "SELECT * FROM directus_users WHERE id='$user_created'";
                        $resultnew = $mysqli->query($sqlnew);
                        while($row=$resultnew->fetch_assoc())
                            {
                                $registration_center = $row['registration_center'];
                                $du_first_name = $row['first_name'];
                                $du_last_name = $row['last_name'];
                                $sqlnew1 = "SELECT * FROM registration_center WHERE id='$registration_center'";
                                $resultnew1 = $mysqli->query($sqlnew1);
                                while($row1=$resultnew1->fetch_assoc())
                                    {
                                        $center_name = $row1['center_name'];
                                        $state_name = $row1['state'];
                                        $lga_name = $row1['lga'];
                                        ?>
                                        <p class="p-value table-p"><?php echo $center_name ?></p>
                                        <?php
                                    }
                            }
                        ?>
                    </div>
                    <div class="col-md-6 ">
                        <p class="table-p"><strong>Locality</strong></p>
                    </div>
                    <div class="col-md-6 ">
                        <?php 
                        $sql1 = 'SELECT * FROM lgas WHERE id=' .$lga_name;
                        $result2 = $mysqli->query($sql1);
                        while($rows1=$result2->fetch_assoc())
                            {
                        ?>
                        <p class="p-value table-p"><?php echo $rows1['name']; ?></p>
                        <?php
                           }
                        ?>
                    </div>
                    <div class="col-md-6 ">
                        <p class="table-p"><strong>L.G.A</strong></p>
                    </div>
                    <div class="col-md-6 ">
                        <?php 
                        $sql1 = 'SELECT * FROM lgas WHERE id=' .$lga_name;
                        $result2 = $mysqli->query($sql1);
                        while($rows1=$result2->fetch_assoc())
                            {
                        ?>
                        <p class="p-value table-p"><?php echo $rows1['name']; ?></p>
                        <?php
                           }
                        ?>
                    </div>
                    <div class="col-md-6 ">
                        <p class="table-p"><strong>State</strong></p>
                    </div>
                    <div class="col-md-6 ">
                        <p class="p-value table-p"><?php echo $state_name ?></p>
                    </div>
                </div>
            </div>
                            <?php
                
                $abv = substr($state_name, 0, 3);
                ?>
            <div class="col-md-5 text-right">
                <p class="table-p"><strong>Certificate ID</strong></p>
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=National Population Commission <?php echo $abv ?>/<?php echo $lga_name?>/<?php echo $registration_center ?>/00<?php echo $rows['id'];?> <?php echo $rows['unique_id'];?>">

                <h6 class="uppercase"><?php echo $abv ?>/<?php echo $lga_name?>/<?php echo $registration_center ?>/00<?php echo $rows['id'];?></h6>
            </div>
            <div class="col-md-12 text-center ">
                <p class="mb-0"><strong>This is to certify that the births, details of which are recorded herein has been registered on</strong></p>
            </div>
            <div class="col-md-4 text-center ">
                <?php
                $date=$rows['date_created'];
                $newDate = date("d-m-Y", strtotime($date)); 
                ?>
                <p class="p-value table-p"><?php echo $newDate; ?></p>
                <p class="table-p"><strong><small style="font-size:12px;">dd/mm/yyyy</small></strong></p>
            </div>
            <div class="col-md-8 ">
                <p class="table-p d-inline mr-2"><strong>at this registration centre:</strong></p>
                <p class="p-value table-p d-inline"><?php echo $center_name ?></p>
            </div>
            <div class="col-md-3 ">
                <p class="table-p"><strong>Full Name:</strong></p>
            </div>
            <div class="col-md-9 text-center ">
                <p class="p-value table-p"><?php echo $rows['surname'];?> <?php echo $rows['first_name'];?> <?php echo $rows['other_name'];?></p>
            </div>
            <div class="col-md-4 ">
                <p class="table-p d-inline mr-2"><strong>Sex:</strong></p>
                <p class="p-value table-p d-inline"><?php echo $rows['sex'];?></p>
            </div>
            <div class="col-md-3 ">
                <p class="table-p"><strong>Date of Birth:</strong></p>
            </div>
            <div class="col-md-5 text-center ">
                <?php
                $ddate=$rows['date_of_birth'];
                $dobdate = date("d-m-Y", strtotime($ddate)); 
                ?>
                <p class="p-value table-p"><?php echo $dobdate;?></p>
                <p class="table-p"><strong><small style="font-size:12px;">dd/mm/yyyy</small></strong></p>
            </div>
            <div class="col-md-6 ">
                <p class="table-p d-inline mr-2"><strong>Place of Birth:</strong></p>
                <p class="p-value table-p d-inline"><?php echo $rows['place_of_occurance'];?></p>
            </div>
            <div class="col-md-6 ">
                <p class="table-p d-inline mr-2"><strong>Locality of Birth:</strong></p>
                <p class="p-value table-p d-inline"><?php echo $rows['locality_of_birth'];?></p>
            </div>
            <div class="col-md-4 ">
                <p class="table-p"><strong>Full Name of Mother:</strong></p>
            </div>
            <div class="col-md-8 text-center ">
                <p class="p-value table-p"><?php echo $rows['mother_fullname'];?></p>
            </div>
            <div class="col-md-4 ">
                <p class="table-p"><strong>Full Name of Father:</strong></p>
            </div>
            <div class="col-md-8 text-center ">
                <p class="p-value table-p"><?php echo $rows['fathers_fullname'];?></p>
            </div>
            <div class="col-md-6 ">
                <p class="table-p d-inline mr-2"><strong>Place of Issue:</strong></p>
                <p class="p-value table-p d-inline"><?php echo $center_name ?></p>
            </div>
            <div class="col-md-6 text-center ">
                <p class="p-value table-p"><?php echo $du_first_name." ".$du_last_name; ?></p>
                <p class="table-p"><strong>Name of Registrar</strong></p>
            </div>
            <div class="col-md-6 ">
                <p class="table-p d-inline mr-2"><strong>Date:</strong></p>
                <p class="p-value table-p d-inline"><?php echo date("d-m-Y") ?></p>
            </div>
            <div class="col-md-6 text-center ">
                <p class="table-p">________________________</p>
                <p class="table-p"><strong>Signature of Registrar</strong></p>
            </div>
            <div class="col-md-12 text-center ">
                <p><strong>NATIONAL REGISTRATION</strong></p>
                <h6><?php echo $rows['unique_id'];?></h6>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
    <script>window.print();</script>
</body>
<?php
                    }   
                    else
                    {
                        echo"Live Birth Record has not been approved";
                    } 
            }
             ?>

</html>