module.exports = function registerEndpoint(router, {services,exceptions}){

    router.get('/',(req,res)=>{

        const { ItemsService }  = services;
        const { ServiceUnavailableException } = exceptions;

        const attestations = new ItemsService('attestation', {schema: req.schema});
        const directors = new ItemsService('director', {schema: req.schema});
        const lgas = new ItemsService('lgas', {schema: req.schema});

        //Get Today's Date
        const today = new Date().toLocaleDateString('en-IN',{year: 'numeric', month: '2-digit', day: '2-digit'})
        // End
        
        //Experimental
        //directors
            //.readOne(req.query.id)
			//.then((results) => res.json(results))
			//.catch((error) => {
				//return next(new ServiceUnavailableException(error.message));
                        //});
        
        
       //Get Directors
       directors.readOne(req.query.id).then((director)=>{
       console.log(director)
       }).catch((error) => {
        return next(new w(error.message));
       });

        attestations
        .readOne(req.query.id)
        .then((data)=>{
              console.log(data)
              

            if(data.status == '2'){

                lgas.readByQuery({}).then((_lgas) => {

                  function lga (x) {
                    return _lgas.filter((l)=>l.id == x)[0] 
                    }
                    console.log(_lgas)
                    
                // now you will get lga data by 
                // lga(<id>).state 
                //lga(2).name


         
                res.send(`
                    <!DOCTYPE html>
                    <html>

                    <head>
                        <meta charset="utf-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
                        <title>print</title>
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">
                    </head>

                    <body class="p-5">
                    <style>
                    body {
                        font-family: 'Source Sans Pro', sans-serif;
                        /*background-color: #fcfcfc;*/
                      }
                      
                      /* Print */
                      
                      .attestation-container {
                        /*margin: 15px auto;*/
                        /*padding: 40px 70px 70px 70px;*/
                        /*max-width: 850px;*/
                        /*background-color: #fff;*/
                        /*border: 1px solid #ccc;*/
                        /*-moz-border-radius: 6px;*/
                        -webkit-border-radius: 6px;
                        -o-border-radius: 6px;
                        /*border-radius: 6px;*/
                      }
                      
                      .bg-grey {
                        background-color: #f1f1f1;
                      }
                      
                      .attest-heading {
                        color: #299913;
                        font-weight: 700;
                      }
                      
                      .attest-subheading {
                        font-weight: 600;
                      }
                      
                      .attest-subheading2 {
                        font-weight: 700;
                        color: #299913;
                      }
                      
                      .attest-heading-p {
                        font-weight: 600;
                        font-size: 16px;
                      }
                      
                      .attest-heading-p2 {
                        font-weight: 600;
                        font-size: 16px;
                      }
                      
                      .attest-heading-small {
                        font-size: 11px;
                      }
                      
                      .underline {
                        text-decoration: underline;
                        text-decoration-style: dotted;
                      }
                      
                      .line {
                        border-bottom: 3px solid #000;
                      }
                      
                      .attest-body-h {
                        font-weight: 600;
                        text-decoration: underline;
                        font-size: 26px;
                      }
                      
                      .attest-body-p {
                        font-size: 18px;
                      }
                      
                      .col-center {
                        border-left: 3px solid #000;
                        border-right: 3px solid #000;
                      }
                      
                      .bg {
                        background-image: url("Group 2.svg");
                        background-position: center;
                        background-size: cover;
                        background-repeat: no-repeat;
                      }
                      
                      .pull-right {
                        float: right;
                      }
                      
                      .box {
                        display: block;
                        border: 2px solid #000;
                      }
                      
                      .box p {
                        font-size: 14px;
                        margin-bottom: 0;
                      }
                      
                      .p-value {
                        border-bottom: 2px solid #000;
                      } 

                      .capital {
                        text-transform: uppercase;
                      }                
                    </style>
                        <div class="container attestation-container bg1">
                            <div class="text-center"><img class="img-fluid" src="http://localhost:8055/assets/9f1ea16d-750d-4197-8351-631d92ad1941" width="80px">
                                <h4 class="attest-subheading">FEDERAL REPUBLIC OF NIGERIA</h4>
                                <h1 class="attest-heading mb-0">NATIONAL POPULATION COMMISSION</h1>
                                <h4 class="attest-subheading">HEADQUATER OFFICE</h4>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <p class="mb-0 attest-heading-p">Website: www.nationalpopulation.gov.ng</p>
                                    <p class="attest-heading-p">Telephone: {{office_phone}}</p>
                                    <p class="attest-heading-small">All correspondence to be addressed to teh Hon.Commissioner in reply, please quote the Reference Number and Date of this letter</p>
                                </div>
                                <div class="col text-center col-center">
                                    <h5 class="attest-subheading2">{{center_name}}</h5>
                                    <p class="mb-0 attest-heading-p">{{center_address}}</p>
                                </div>
                                <div class="col">
                                    <p class="mb-0 attest-heading-p2">Ref No:<span class="underline">{{ref_number}}</span></p>
                                    <p class="mb-0 attest-heading-p2">Date:<span class="underline"> ${today}</span></p>
                                </div>
                            </div>
                            <div class="line"></div>
                            <div class="row mt-3">
                                <div class="col-md-12 mb-5">
                                    <div class="text-center">
                                        <h5 class="attest-body-h mb-5 mt-4">TO WHOM IT MAY CONCERN<br>ATTESTATION OF BIRTH <span class="capital">${data.surname} ${data.first_name} ${data.other_name}</span></h5>
                                    </div>
                                    <p class="attest-body-p">Act No. 69 of December, 1992 on Births, Deaths etc. (Compulsory Registration) of the Federal Government of Nigeria assigned the function of the registration of Births, Deaths, Marriages, Divorces etc. and the issuance of such relevant certificates to National Population Commission with effect from 1998.</p>
                                    <p class="attest-body-p">With reference to the application for letter of Attestation of Birth <span class="capital"><strong>${data.surname} ${data.first_name} ${data.other_name}</strong></span><strong>&nbsp;</strong>and a copy of statutory Declaration of age of <span class="capital"><strong>${data.age_declaration_date}</strong></span><strong>&nbsp;</strong>obtained at the ${data.court_name} at ${data.court_address}, Nigeria.</p>
                                    <p class="attest-body-p"><span class="capital"><strong>${data.surname} ${data.first_name} ${data.other_name}</strong></span>&nbsp;was born in&nbsp;<span class="capital"><strong>${data.place_of_birth}</strong></span>&nbsp;in&nbsp;<span class="capital"><strong>${lga(data.lga_place_of_birth).name}</strong></span>&nbsp;Local Government Area of&nbsp;<span class="capital"><strong>${data.state_place_of_birth}</strong></span>&nbsp;State on the&nbsp;<span class="capital"><strong>${data.date_of_birth}</strong></span>&nbsp;to the Family of MR.&nbsp;&nbsp;<span class="capital"><strong>${data.fathers_name}</strong></span>&nbsp;Father from&nbsp;<span class="capital"><strong>${data.f_village_town}</strong></span>&nbsp;in&nbsp;<span class="capital"><strong>${lga(data.f_lga).name}</strong></span>&nbsp;Local Government Area of&nbsp;<span class="capital"><strong>${data.f_state_of_origin}</strong></span>&nbsp;State and MRS.&nbsp;<span class="capital"><strong>${data.mothers_name}</strong></span>&nbsp;Mother from&nbsp;<span class="capital"><strong>${data.m_village_town}</strong></span>&nbsp;in&nbsp;<span class="capital"><strong>${lga(data.m_lga).name}</strong></span>&nbsp;Local Government Area of&nbsp;<span class="capital"><strong>${data.m_state_of_origin}</strong></span>&nbsp;State and that&nbsp;<span class="capital"><strong>${data.surname} ${data.first_name} ${data.other_name}</strong></span>&nbsp;is an indigene of&nbsp;<span class="capital"><strong>${data.v_town_of_origin}</strong></span>&nbsp;in&nbsp;<span class="capital"><strong>${lga(data.lga).name}</strong></span>&nbsp;Local Government Area of&nbsp;<span class="capital"><strong>${data.state_of_origin}</strong></span>&nbsp;State of Nigeria.</p>
                                    <p class="attest-body-p">This falls beyond the coverage of the Act No. 69 of December, 1992 for issuance of Birth Certificate</p>
                                    <p class="attest-body-p">In the light of the above information, gratefully accepted this Birth Attestation Letter in respect of&nbsp;<span class="capital"><strong>${data.surname} ${data.first_name} ${data.other_name}</strong></span></p>
                                    <p class="attest-body-p">Thanks for your usual Co-operation.</p>
                                </div>
                                <div class="col">
                                    <div><img src="#" width="60"></div>
                                    <h5 class="mb-0">${data.director_name}</h5>
                                    <h5 class="mb-0">DIRECTOR</h5>
                                    <h5 class="mb-0">FOR: HON. FED. COMMISSIONER.</h5>
                                </div>
                                <div class="col text-right"><img class="img-fluid" src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=http://localhost:8055/admin/collections/attestation/${data.id}"></div>
                            </div>
                        </div>
                        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
                        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
                        <script> // window.print(); </script>
                    </body>

                    </html>
                `);

              


                }).catch(error=>{throw error;});//lga end
            }
            else res.send('NOT APPROVED')
        })
        .catch((error) => {
            return next(new ServiceUnavailableException(error.message));
        });//attestation end



    //router end    
    });
//module export end
}